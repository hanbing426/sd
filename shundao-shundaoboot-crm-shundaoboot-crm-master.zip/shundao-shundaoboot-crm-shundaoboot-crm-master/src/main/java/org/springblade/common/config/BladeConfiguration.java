/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.common.config;


import org.springblade.common.filter.PreviewFilter;
import org.springblade.core.secure.registry.SecureRegistry;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Blade配置
 *
 * @author Chill
 */
@Configuration
public class BladeConfiguration implements WebMvcConfigurer {

	@Bean
	public SecureRegistry secureRegistry() {
		SecureRegistry secureRegistry = new SecureRegistry();
		secureRegistry.setEnabled(true);


		secureRegistry.excludePathPatterns("/phoneReturnMoney/setFormDataId");//关闭表单中转器拦截器
		secureRegistry.excludePathPatterns("/phoneReturnMoney/getFormDataId");//关闭表单中转器拦截器
		secureRegistry.excludePathPatterns("/login/**");//关闭企业微信登录授权拦截器
//		secureRegistry.excludePathPatterns("/phoneOrganization/phoneOrganization/**");//关闭机构拦截器
		secureRegistry.excludePathPatterns("/token/**");//关闭微信拦截器
		secureRegistry.excludePathPatterns("/verify/**");//关闭获取access_token拦截
		secureRegistry.excludePathPatterns("/customerdata/customerformdata/**");//关闭表单数据拦截器
		secureRegistry.excludePathPatterns("/customer/customerform/**");//关闭表单自定义页面拦截器
//		secureRegistry.excludePathPatterns("/phoneContacts/phoneContacts/**");//关闭联系人拦截器
//		secureRegistry.excludePathPatterns("/phoneContactsDetail/phoneContactsDetail/**");//关闭联系人详情拦截器
		secureRegistry.excludePathPatterns("/login/userLogin/**");
		secureRegistry.excludePathPatterns("/blade-auth/**");
		secureRegistry.excludePathPatterns("/blade-log/**");
		secureRegistry.excludePathPatterns("/blade-system/menu/routes");
		secureRegistry.excludePathPatterns("/blade-system/menu/auth-routes");
		secureRegistry.excludePathPatterns("/blade-system/menu/top-menu");
		secureRegistry.excludePathPatterns("/blade-system/tenant/info");
		secureRegistry.excludePathPatterns("/blade-flow/process/resource-view");
		secureRegistry.excludePathPatterns("/blade-flow/process/diagram-view");
		secureRegistry.excludePathPatterns("/blade-flow/manager/check-upload");
		secureRegistry.excludePathPatterns("/doc.html");
		secureRegistry.excludePathPatterns("/js/**");
		secureRegistry.excludePathPatterns("/webjars/**");
		secureRegistry.excludePathPatterns("/swagger-resources/**");
		secureRegistry.excludePathPatterns("/druid/**");
		return secureRegistry;
	}

	@Bean
	@ConditionalOnProperty(value = "blade.preview.enabled", havingValue = "true")
	public PreviewFilter previewFilter() {
		return new PreviewFilter();
	}

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**")
			.allowedOrigins("*")
			.allowedHeaders("*")
			.allowedMethods("*")
			.maxAge(3600)
			.allowCredentials(true);
	}

}
