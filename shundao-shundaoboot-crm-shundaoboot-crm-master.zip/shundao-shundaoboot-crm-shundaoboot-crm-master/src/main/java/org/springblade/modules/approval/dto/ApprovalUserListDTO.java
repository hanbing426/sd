package org.springblade.modules.approval.dto;

import io.swagger.models.auth.In;
import lombok.Data;
import org.springblade.modules.approval.entity.Approval;
import org.springblade.modules.system.entity.User;

import java.util.List;

@Data
public class ApprovalUserListDTO extends Approval {

	private List<User> userList;

}
