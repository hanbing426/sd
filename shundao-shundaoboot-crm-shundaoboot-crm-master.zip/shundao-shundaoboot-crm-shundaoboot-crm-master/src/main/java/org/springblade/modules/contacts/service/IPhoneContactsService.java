package org.springblade.modules.contacts.service;

import org.springblade.core.mp.base.BaseService;
import org.springblade.core.tool.api.R;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.vo.ContactsListVO;
import org.springblade.modules.contacts.vo.ContactsRemindListVo;
import org.springblade.modules.enclosure.entity.Enclosure;

import java.util.List;
import java.util.Map;

public interface IPhoneContactsService extends BaseService<Contacts> {

	/**
	 * 搜索 联系人表
	 * @param labelId
	 * @param deptId
	 * @param roleId
	 * @return
	 */
//	List selectContacts(String labelId, String deptId, String roleId);

	/**
	 * 新增 联系人表
	 * @param contacts
	 * @param enclosure
	 * @param remarks
	 * @return
	 */
	R saveContacts(Contacts contacts , String enclosure , String remarks);

	/**
	 * 搜索 联系人表规则
	 * @return
	 */
	R selectContactsRule();

	/**
	 * 列表展示 联系人表
	 * @param contacts
	 * @return
	 */
	R contactsList(Contacts contacts);

	Map contactsHighseasList(String highseasId , String deptId);


	ContactsRemindListVo contactAgencyList();



}
