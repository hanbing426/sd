package org.springblade.modules.highseasrule.task;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

public class HighseasRuleUtil {

	private static final SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
	public static String getCron(Date date){
		String formatTimeStr = null;
		if (Objects.nonNull(date)) {
			formatTimeStr = sdf.format(date);
		}
		return formatTimeStr;
	}
}
