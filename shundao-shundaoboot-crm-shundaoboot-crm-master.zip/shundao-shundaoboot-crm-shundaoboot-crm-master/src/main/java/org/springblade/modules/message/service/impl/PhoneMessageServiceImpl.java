package org.springblade.modules.message.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.secure.utils.SecureUtil;
import org.springblade.core.tool.api.R;
import org.springblade.modules.message.entity.Message;
import org.springblade.modules.message.mapper.MessageMapper;
import org.springblade.modules.message.service.IMessageService;
import org.springblade.modules.message.service.IPhoneMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PhoneMessageServiceImpl extends BaseServiceImpl<MessageMapper, Message> implements IPhoneMessageService {

	@Autowired
	private IMessageService messageService;

	@Override
	public List<Message> messageList() {
		String userId = String.valueOf(SecureUtil.getUserId());
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("sd_user_id",userId);
		queryWrapper.eq("sd_message_type",0);
		List<Message> list = messageService.list(queryWrapper);
		return list;
	}

	@Override
	public Map newMessageCount() {
		Long userId = SecureUtil.getUserId();
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("sd_user_id",String.valueOf(userId));
		queryWrapper.eq("sd_contacts_id",0);
		queryWrapper.eq("sd_message_type",0);
		int count = messageService.count(queryWrapper);
		Map map = new HashMap();
		map.put("count",count);
		return map;
	}

	@Override
	public R ReadMessage(Message message) {
		message.setSdIsRead(1);
		return R.status(messageService.saveOrUpdate(message));
	}

	@Override
	public List<Message> approvalMessageList() {

		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("sd_user_id",String.valueOf(SecureUtil.getUserId()));
		queryWrapper.eq("sd_message_type",1);
		List<Message> list = messageService.list(queryWrapper);
		return list;
	}
}
