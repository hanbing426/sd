package org.springblade.modules.returnMoney.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.secure.utils.SecureUtil;
import org.springblade.core.tool.api.R;
import org.springblade.modules.approval.entity.Approval;
import org.springblade.modules.approval.service.IApprovalService;
import org.springblade.modules.customapprovalmenu.entity.CustomApprovalMenu;
import org.springblade.modules.customapprovalmenu.service.ICustomApprovalMenuService;
import org.springblade.modules.returnMoney.entity.ReturnMoney;
import org.springblade.modules.returnMoney.mapper.ReturnMoneyMapper;
import org.springblade.modules.returnMoney.service.IPhoneReturnMoneyService;
import org.springblade.modules.returnMoney.service.IReturnMoneyService;
import org.springblade.modules.sdapprovalgroup.entity.ApprovalGroup;
import org.springblade.modules.sdapprovalgroup.service.IApprovalGroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PhoneReturnMoneyServiceImpl extends BaseServiceImpl<ReturnMoneyMapper, ReturnMoney> implements IPhoneReturnMoneyService {


	@Autowired
	private ReturnMoneyMapper returnMoneyMapper;

	@Autowired
	private IReturnMoneyService returnMoneyService;

	@Autowired
	private ICustomApprovalMenuService customApprovalMenuService;

	@Autowired
	private IApprovalGroupService approvalGroupService;

	@Autowired
	private IApprovalService approvalService;


	@Override
	public List<ReturnMoney> returnMoneyList() {
		Long userId = SecureUtil.getUserId();
		return returnMoneyMapper.returnMoneyList(String.valueOf(userId));
	}

	@Override
	public R saveReturnMoney(ReturnMoney returnMoney) {
		String sdReturnMoneyMenuId = returnMoney.getSdReturnMoneyMenuId();
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("id",sdReturnMoneyMenuId);
		List <CustomApprovalMenu> CustomApprovalMenuList = customApprovalMenuService.list(queryWrapper);
		if(CustomApprovalMenuList.size()>0){
			CustomApprovalMenu customApprovalMenu = CustomApprovalMenuList.get(0);
			String sdCustomApprovalMenuGroup = customApprovalMenu.getSdCustomApprovalMenuGroup();
			QueryWrapper queryWrapper1 = new QueryWrapper();
			queryWrapper1.eq("id",sdCustomApprovalMenuGroup);
			List<ApprovalGroup> ApprovalGroupList = approvalGroupService.list(queryWrapper1);
			if(ApprovalGroupList.size()>0){
				QueryWrapper approvalQueryWrapper = new QueryWrapper();
				approvalQueryWrapper.eq("sd_approval_group_id",sdCustomApprovalMenuGroup);
				approvalQueryWrapper.eq("sd_approval_index",1);
				List<Approval> approvalList = approvalService.list(approvalQueryWrapper);
				if(approvalList.size()>0){
					Approval approval = approvalList.get(0);
					returnMoney.setSdReturnMoneyApprovalConduct(String.valueOf(approval.getId()));
					returnMoney.setSdReturnMoneyApprovalIndex(1);
				}else {
					return R.fail(32,"未查询到Index为1的审核节点");
				}
			}else {
				return R.fail(30,"按钮表审核组ID有误无法查出响应数据");
			}
		}else {
			return R.fail(31,"回款表按钮ID有误 无法查出按钮数据");
		}
		returnMoney.setSdReturnMoneyApprovalIndex(0);
		return R.data(this.saveOrUpdate(returnMoney));
	}
}
