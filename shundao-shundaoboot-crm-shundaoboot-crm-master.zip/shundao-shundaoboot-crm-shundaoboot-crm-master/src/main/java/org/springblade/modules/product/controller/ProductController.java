/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.product.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import lombok.AllArgsConstructor;
import javax.validation.Valid;

import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestParam;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.modules.product.entity.Product;
import org.springblade.modules.product.vo.ProductVO;
import org.springblade.modules.product.service.IProductService;
import org.springblade.core.boot.ctrl.BladeController;

/**
 * 产品信息表 控制器
 *
 * @author BladeX
 * @since 2020-05-22
 */
@RestController
@AllArgsConstructor
@RequestMapping("product/product")
@Api(value = "产品信息表", tags = "产品信息表接口")
public class ProductController extends BladeController {

	private IProductService productService;

	/**
	 * 详情
	 */
	@GetMapping("/detail")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入product")
	public R<Product> detail(Product product) {
		Product detail = productService.getOne(Condition.getQueryWrapper(product));
		return R.data(detail);
	}

	/**
	 * 分页 产品信息表
	 */
	@GetMapping("/list")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "分页", notes = "传入product")
	public R<IPage<Product>> list(Product product, Query query) {
		IPage<Product> pages = productService.page(Condition.getPage(query), Condition.getQueryWrapper(product));
		return R.data(pages);
	}

	/**
	 * 自定义分页 产品信息表
	 */
	@GetMapping("/page")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页", notes = "传入product")
	public R<IPage<ProductVO>> page(ProductVO product, Query query) {
		IPage<ProductVO> pages = productService.selectProductPage(Condition.getPage(query), product);
		return R.data(pages);
	}

	/**
	 * 新增 产品信息表
	 */
	@PostMapping("/save")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "新增", notes = "传入product")
	public R save(@Valid @RequestBody Product product) {
		return R.status(productService.save(product));
	}

	/**
	 * 修改 产品信息表
	 */
	@PostMapping("/update")
	@ApiOperationSupport(order = 5)
	@ApiOperation(value = "修改", notes = "传入product")
	public R update(@Valid @RequestBody Product product) {
		return R.status(productService.updateById(product));
	}

	/**
	 * 新增或修改 产品信息表
	 */
	@PostMapping("/submit")
	@ApiOperationSupport(order = 6)
	@ApiOperation(value = "新增或修改", notes = "传入product")
	public R submit(@Valid @RequestBody Product product) {
		return R.status(productService.saveOrUpdate(product));
	}

	
	/**
	 * 删除 产品信息表
	 */
	@PostMapping("/remove")
	@ApiOperationSupport(order = 7)
	@ApiOperation(value = "逻辑删除", notes = "传入ids")
	public R remove(@ApiParam(value = "主键集合", required = true) @RequestParam String ids) {
		return R.status(productService.deleteLogic(Func.toLongList(ids)));
	}

	
}
