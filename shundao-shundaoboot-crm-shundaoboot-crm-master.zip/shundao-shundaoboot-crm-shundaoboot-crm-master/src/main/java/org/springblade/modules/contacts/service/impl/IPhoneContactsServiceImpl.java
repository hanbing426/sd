package org.springblade.modules.contacts.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.secure.utils.SecureUtil;
import org.springblade.core.tool.api.R;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.mapper.ContactsMapper;
import org.springblade.modules.contacts.service.IContactsService;
import org.springblade.modules.contacts.service.IPhoneContactsService;
import org.springblade.modules.contacts.vo.ContactsListVO;
import org.springblade.modules.contacts.vo.ContactsRemindListVo;
import org.springblade.modules.contacts.vo.ContactsVO;
import org.springblade.modules.enclosure.entity.Enclosure;
import org.springblade.modules.enclosure.service.IEnclosureService;
import org.springblade.modules.highseas.entity.HighSeas;
import org.springblade.modules.highseas.service.IHighSeasService;
import org.springblade.modules.labels.entity.Labels;
import org.springblade.modules.labels.service.ILabelsService;
import org.springblade.modules.message.entity.Message;
import org.springblade.modules.message.service.IMessageService;
import org.springblade.modules.remarks.entity.Remarks;
import org.springblade.modules.remarks.service.IRemarksService;
import org.springblade.modules.system.entity.Dept;
import org.springblade.modules.system.entity.Role;
import org.springblade.modules.system.service.IDeptService;
import org.springblade.modules.system.service.IRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.constraints.NotEmpty;
import java.util.*;
import java.util.function.Function;

@Service

public class IPhoneContactsServiceImpl extends BaseServiceImpl<ContactsMapper, Contacts> implements IPhoneContactsService {

	@Autowired
	private ILabelsService labelsService;

	@Autowired
	private IDeptService deptService;

	@Autowired
	private IRemarksService remarksService;

	@Autowired
	private IEnclosureService enclosureService;

	@Autowired
	private IHighSeasService highSeasService;

	@Autowired
	private ContactsMapper contactsMapper;


	@Override
	public R contactsList(Contacts contacts) {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("sd_contacts_is_high_seas", 0);
		return R.data(this.list(queryWrapper));
	}

	@Override
	public Map contactsHighseasList(String highseasId, String deptId) {
		Map map = new HashMap();
		if(highseasId==null){
			List<HighSeas> list = highSeasService.list();
			HighSeas highSeas = list.get(0);
			List<ContactsListVO> listVOS = contactsMapper.contactsHighseasList(String.valueOf(highSeas.getId()), deptId);
			map.put("highseasList",listVOS);
			return map;
		}else {
			List<ContactsListVO> listVOS = contactsMapper.contactsHighseasList(highseasId, deptId);
			map.put("highseasList",listVOS);
			return map;
		}
	}

	/**
	 * 代办联系人
	 * @return
	 */
	@Override
	public ContactsRemindListVo contactAgencyList() {
		String s = contactsMapper.customerNotFollowedUpFor7Days();
		String s1 = contactsMapper.sevenDayBirthday();
		ContactsRemindListVo contactsRemindListVo = new ContactsRemindListVo();
		contactsRemindListVo.setSevenDayBirthday(s1);
		contactsRemindListVo.setCustomerNotFollowedUpFor7Days(s);
		return contactsRemindListVo;
	}



	@Override
	public R saveContacts(Contacts contacts, String enclosure, String remarks) {
		try {
			Enclosure enclosureOne = new Enclosure();
			this.saveOrUpdate(contacts);
			Long contactsId = contacts.getId();
			enclosureOne.setSdBusinessId(String.valueOf(contactsId));
			enclosureOne.setSdEnclosureUrl(enclosure);
			enclosureService.saveOrUpdate(enclosureOne);
			QueryWrapper queryWrapper = new QueryWrapper();
			queryWrapper.eq("sd_contacts_id", contacts.getId());
			Remarks re = remarksService.getOne(queryWrapper);
			re.setSdContactsId(String.valueOf(contactsId));
			re.setSdRemarks(remarks);
			remarksService.saveOrUpdate(re);
		} catch (Exception e) {
			e.printStackTrace();
			return R.success("位置错误");
		}
		Message message = new Message();
		String userName = SecureUtil.getUserName();
		String msg = "新建联系人:"+contacts.getSdContactsName();
		message.setSdIsRead(0);
		message.setSdOperationText(msg);
		message.setSdUserId(String.valueOf(SecureUtil.getUserId()));
		return R.success("成功");
	}

	@Override
	public R selectContactsRule() {
		Map map = new HashMap();
		List<Labels> labelsList = labelsService.list();
		List<Dept> deptList = deptService.list();
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("dept_category",4);
		List<Dept> categoryList = deptService.list(queryWrapper);
		map.put("deptList",deptList);
		map.put("labelsList",labelsList);
		map.put("categoryList",categoryList);
		return R.data(map);
	}

}
