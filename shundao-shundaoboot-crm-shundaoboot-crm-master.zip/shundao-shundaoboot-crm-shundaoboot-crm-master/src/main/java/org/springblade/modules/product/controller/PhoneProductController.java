package org.springblade.modules.product.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.secure.annotation.PreAuth;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.constant.RoleConstant;
import org.springblade.modules.product.entity.Product;
import org.springblade.modules.product.service.IProductService;
import org.springblade.modules.product.vo.ProductDetailVO;
import org.springblade.modules.system.entity.User;
import org.springblade.modules.system.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/phoneProduct/phoneProduct")
@Api(value = "后端产品信息表", tags = "后端产品信息表接口")
//@PreAuth(RoleConstant.HAS_ROLE_USER)
public class PhoneProductController {

	@Autowired
	private IProductService productService;

	/**
	 * 分页 产品信息表
	 */
	@GetMapping("/productList")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "客户端产品查询列表")
	public R productList() {
		List<Product> list = productService.list();
		return R.data(list);
	}

	@GetMapping("/productDetail")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "客户端产品查询列表")
	public R productDetail(String productId) {
		ProductDetailVO productDetailVO = productService.productDetail(productId);
		return R.data(productDetailVO);
	}

}
