package org.springblade.modules.enclosure.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.enclosure.entity.Enclosure;
import org.springblade.modules.enclosure.mapper.EnclosureMapper;
import org.springblade.modules.enclosure.service.IPhoneEnclosureService;
import org.springframework.stereotype.Service;

@Service
public class IPhoneEnclosureServiceImpl extends BaseServiceImpl<EnclosureMapper, Enclosure> implements IPhoneEnclosureService {


	@Override
	public R enclosureList(String ContactsId) {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("sd_business_id",ContactsId);
		return R.data(this.list(queryWrapper));
	}
}
