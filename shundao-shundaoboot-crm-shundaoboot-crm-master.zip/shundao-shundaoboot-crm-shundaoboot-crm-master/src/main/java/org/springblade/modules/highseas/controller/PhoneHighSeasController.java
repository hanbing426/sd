package org.springblade.modules.highseas.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springblade.core.boot.ctrl.BladeController;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.secure.annotation.PreAuth;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.constant.RoleConstant;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.service.IContactsService;
import org.springblade.modules.highseas.entity.HighSeas;
import org.springblade.modules.highseas.service.IHighSeasService;
import org.springblade.modules.highseas.service.IphoneHighSeasService;
import org.springblade.modules.highseas.vo.HighSeasVO;
import org.springblade.modules.highseas.wrapper.HighSeasWrapper;
import org.springblade.modules.highseasrule.service.IHighSeasRuleService;
import org.springblade.modules.message.service.IMessageService;
import org.springblade.modules.system.entity.Dept;
import org.springblade.modules.system.service.IDeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.Console;
import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/iphoneHighSeas/iphoneHighSeas")
@Api(value = "客户端公海表", tags = "客户端公海表接口")
//@PreAuth(RoleConstant.HAS_ROLE_USER)
public class PhoneHighSeasController extends BladeController {

	@Autowired
	private IphoneHighSeasService iphoneHighSeasService;


	/**
	 * 分页 公海表
	 */
	@GetMapping("/highSeaslist")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "公海规则", notes = "传入公海，分页")
	public R highSeaslist() {
		return R.data(iphoneHighSeasService.highSeaslist());
	}

	/**
	 * 查询 机构表
	 */
	@GetMapping("/deptList")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "机构规则")
	public R deptList() {
			return iphoneHighSeasService.deptList();
	}

	/**
	 *
	 */



}
