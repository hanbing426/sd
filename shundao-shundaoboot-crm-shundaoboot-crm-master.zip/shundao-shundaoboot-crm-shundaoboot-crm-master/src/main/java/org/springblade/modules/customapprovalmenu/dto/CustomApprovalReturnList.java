package org.springblade.modules.customapprovalmenu.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springblade.modules.system.entity.User;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Map;

@Data
public class CustomApprovalReturnList {

	private static final long serialVersionUID = 1L;


	private Long id;
	/**
	 * 本次回款金额
	 */
	@ApiModelProperty(value = "本次回款金额")
	private BigDecimal sdReturnMoney;
	/**
	 * 回款时间
	 */
	@org.springframework.format.annotation.DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@com.fasterxml.jackson.annotation.JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@ApiModelProperty(value = "回款时间")
	private LocalDateTime sdReturnMoneyTime;
	/**
	 * 付款方式
	 */
	@ApiModelProperty(value = "付款方式")
	private String sdReturnMoneyType;
	/**
	 * 回款备注
	 */
	@ApiModelProperty(value = "回款备注")
	private String sdReturnMoneyRemarks;
	/**
	 * 回款所属联系人
	 */
	@ApiModelProperty(value = "回款所属联系人")
	private String sdReturnMoneyContactsId;
	/**
	 * 回款所属公司
	 */
	@ApiModelProperty(value = "回款所属公司")
	private Map sdReturnMoneyDeptId;
	/**
	 * 自定义表单数据ID
	 */
	@ApiModelProperty(value = "自定义表单数据ID")
	private String sdReturnMoneyCustomId;

	private String sdReturnMoneyMenuId;

	private String sdReturnMoneyApprovalConduct;

	private Date createTime;

	private Date updateTime;

	private Integer status;

	private String createUser;

	private CustomApprovalMenuList customApprovalMenuList;

	private User userDetail;

	private Integer sdReturnMoneyApprovalIndex;
	/**
	 * 自定义表单结构ID
	 */
	@ApiModelProperty(value = "自定义表单结构ID")
	private String sdCustomApprovalMenuFormDataId;
}
