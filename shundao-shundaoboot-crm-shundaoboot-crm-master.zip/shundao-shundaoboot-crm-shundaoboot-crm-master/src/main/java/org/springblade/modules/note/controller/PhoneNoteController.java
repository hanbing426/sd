package org.springblade.modules.note.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.secure.BladeUser;
import org.springblade.core.secure.annotation.PreAuth;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.constant.RoleConstant;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.service.IContactsService;
import org.springblade.modules.note.entity.Note;
import org.springblade.modules.note.service.INoteService;
import org.springblade.modules.note.service.IPhoneNoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("PhoneNoteController/PhoneNoteController")
@Api(value = "后端笔记", tags = "笔记接口")
//@PreAuth(RoleConstant.HAS_ROLE_USER)
public class PhoneNoteController {

	@Autowired
	private IPhoneNoteService phoneNoteService;

	/**
	 *新增 笔记联系人选择
	 */
	@GetMapping
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "根据联系人新增笔记", notes = "传入笔记对象，联系人，分页")
	public R<IPage<Contacts>> noteContactsList(Note note , Contacts contacts, Query query) {
		return phoneNoteService.noteContactsList(note,contacts,query);
	}

	/**
	 * 新增 笔记表
	 */
	@PostMapping("/saveNote")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "新增笔记", notes = "传入笔记对象，联系人")
	public R saveNote( Note note,String contactsId) {
		return phoneNoteService.saveNote(note,contactsId);
	}

	/**
	 *分页 笔记
	 */
	@PostMapping("/listNote")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页查询笔记")
	public R listNote(Note note) {
		return R.data(phoneNoteService.list());
	}

}
