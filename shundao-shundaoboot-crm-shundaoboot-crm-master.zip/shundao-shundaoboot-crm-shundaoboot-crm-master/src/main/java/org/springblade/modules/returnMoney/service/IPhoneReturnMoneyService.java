package org.springblade.modules.returnMoney.service;

import org.springblade.core.mp.base.BaseService;
import org.springblade.core.tool.api.R;
import org.springblade.modules.returnMoney.entity.ReturnMoney;

import java.util.List;

public interface IPhoneReturnMoneyService extends BaseService<ReturnMoney> {


	List<ReturnMoney> returnMoneyList();

	R saveReturnMoney(ReturnMoney returnMoney);
}
