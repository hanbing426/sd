/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.productclass.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import lombok.AllArgsConstructor;
import javax.validation.Valid;

import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestParam;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.modules.productclass.entity.ProductClass;
import org.springblade.modules.productclass.vo.ProductClassVO;
import org.springblade.modules.productclass.service.IProductClassService;
import org.springblade.core.boot.ctrl.BladeController;

import java.util.List;

/**
 * 产品分类表
 控制器
 *
 * @author BladeX
 * @since 2020-05-22
 */
@RestController
@AllArgsConstructor
@RequestMapping("productclass/productclass")
@Api(value = "产品分类表", tags = "产品分类表接口")
public class ProductClassController extends BladeController {

	private IProductClassService productClassService;

	/**
	 * 详情
	 */
	@GetMapping("/detail")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入productClass")
	public R<ProductClass> detail(ProductClass productClass) {
		ProductClass detail = productClassService.getOne(Condition.getQueryWrapper(productClass));
		return R.data(detail);
	}


	/**
	 * 返回树形结构数据

	 */
	@GetMapping("/formatList")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "树形结构数据", notes = "传入productClass")
	public R<List<ProductClassVO>> formatList(ProductClassVO productClass, Query query) {
		List<ProductClassVO> pclassList  = productClassService.getNodeTree(productClass);

		return R.data(pclassList);
	}


	/**
	 * 分页 产品分类表

	 */
	@GetMapping("/list")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "分页", notes = "传入productClass")
	public R<IPage<ProductClassVO>> list(ProductClassVO productClass, Query query) {
		IPage<ProductClassVO> pages = productClassService.selectProductClassPage(Condition.getPage(query),productClass);
		return R.data(pages);
	}

	/**
	 * 自定义分页 产品分类表

	 */
	@GetMapping("/page")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页", notes = "传入productClass")
	public R<IPage<ProductClassVO>> page(ProductClassVO productClass, Query query) {
		IPage<ProductClassVO> pages = productClassService.selectProductClassPage(Condition.getPage(query), productClass);
		return R.data(pages);
	}

	/**
	 * 新增 产品分类表

	 */
	@PostMapping("/save")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "新增", notes = "传入productClass")
	public R save(@Valid @RequestBody ProductClass productClass) {
		return R.status(productClassService.save(productClass));
	}

	/**
	 * 修改 产品分类表

	 */
	@PostMapping("/update")
	@ApiOperationSupport(order = 5)
	@ApiOperation(value = "修改", notes = "传入productClass")
	public R update(@Valid @RequestBody ProductClass productClass) {
		return R.status(productClassService.updateById(productClass));
	}

	/**
	 * 新增或修改 产品分类表

	 */
	@PostMapping("/submit")
	@ApiOperationSupport(order = 6)
	@ApiOperation(value = "新增或修改", notes = "传入productClass")
	public R submit(@Valid @RequestBody ProductClass productClass) {
		return R.status(productClassService.saveOrUpdate(productClass));
	}


	/**
	 * 删除 产品分类表

	 */
	@PostMapping("/remove")
	@ApiOperationSupport(order = 7)
	@ApiOperation(value = "逻辑删除", notes = "传入ids")
	public R remove(@ApiParam(value = "主键集合", required = true) @RequestParam String ids) {
		return R.status(productClassService.deleteLogic(Func.toLongList(ids)));
	}


}
