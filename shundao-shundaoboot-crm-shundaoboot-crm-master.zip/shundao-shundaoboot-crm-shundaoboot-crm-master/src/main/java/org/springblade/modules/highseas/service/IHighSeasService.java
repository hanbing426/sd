/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.highseas.service;

import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.modules.highseas.dto.HighSeasDTO;
import org.springblade.modules.highseas.entity.HighSeas;
import org.springblade.modules.highseas.vo.HighSeasVO;
import org.springblade.core.mp.base.BaseService;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.List;

/**
 * 公海表 服务类
 *
 * @author BladeX
 * @since 2020-05-27
 */
public interface IHighSeasService extends BaseService<HighSeas> {

	/**
	 * 自定义分页
	 *
	 * @param page
	 * @param highSeas
	 * @return
	 */
	IPage<HighSeasVO> selectHighSeasPage(IPage<HighSeasVO> page, HighSeasVO highSeas);

	/**
	 * 获取公海及权限混合数据实体
	 * @param highSeas
	 * @return
	 */
	HighSeasDTO getHighSeasDtoOne(HighSeas highSeas);

	/**
	 * 分离公海及权限数据并保存或更新
	 * @param highSeasdto
	 */
	boolean highSeasDtoToTwoSave(HighSeasDTO highSeasdto);

	/**
	 * 根据公海主表的ID列表批量删除
	 * 包含删除附表权限表数据
	 * 删除为逻辑删除
	 * @param ids
	 * @return
	 */
	boolean deleteHighSeasRuleListByHighSeasIds(List<Long> ids);

	 R contactsList(Query query);
}
