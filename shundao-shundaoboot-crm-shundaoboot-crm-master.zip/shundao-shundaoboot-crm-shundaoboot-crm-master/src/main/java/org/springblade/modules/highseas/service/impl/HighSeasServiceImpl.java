/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.highseas.service.impl;

import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.StringUtil;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.service.IContactsService;
import org.springblade.modules.highseas.dto.HighSeasDTO;
import org.springblade.modules.highseas.entity.HighSeas;
import org.springblade.modules.highseas.vo.HighSeasVO;
import org.springblade.modules.highseas.mapper.HighSeasMapper;
import org.springblade.modules.highseas.service.IHighSeasService;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.modules.highseasrule.entity.HighSeasRule;
import org.springblade.modules.highseasrule.mapper.HighSeasRuleMapper;
import org.springblade.modules.highseasrule.service.IHighSeasRuleService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.ArrayList;
import java.util.List;


/**
 * 公海表 服务实现类
 *
 * @author BladeX
 * @since 2020-05-27
 */
@Service
public class HighSeasServiceImpl extends BaseServiceImpl<HighSeasMapper, HighSeas> implements IHighSeasService {
	@Autowired
	private IHighSeasRuleService highSeasRuleService;


	@Autowired
	private IContactsService contactsService;
	@Override
	public IPage<HighSeasVO> selectHighSeasPage(IPage<HighSeasVO> page, HighSeasVO highSeas) {
		return page.setRecords(baseMapper.selectHighSeasPage(page, highSeas));
	}

	@Override
	public HighSeasDTO getHighSeasDtoOne(HighSeas highSeas) {
		HighSeas highSeasDetail = this.getOne(Condition.getQueryWrapper(highSeas));
		HighSeasRule highSeasRuleDetail = highSeasRuleService.query().eq("sd_high_seas_id",highSeas.getId()).one();

		return mergeDataAndHighSeasDto(highSeasDetail,highSeasRuleDetail);
	}

	@Override
	public boolean highSeasDtoToTwoSave(HighSeasDTO highSeasdto) {
		HighSeas  highSeas= new HighSeas();
		HighSeasRule  highSeasRule= getHighSeasRuleReturnRule(highSeasdto);
		BeanUtils.copyProperties(highSeasdto,highSeas);
		if(!StringUtil.isEmpty(highSeasdto.getId())){
			HighSeasRule highSeasRuleNew = highSeasRuleService.query().eq("sd_high_seas_id",highSeasRule.getSdHighSeasId()).one();
			highSeasRule.setId(highSeasRuleNew.getId());
		 return this.updateById(highSeas)&&highSeasRuleService.updateById(highSeasRule);
		}else{
//			this.highSeasMapper.insert(highSeas);
			this.saveOrUpdate(highSeas);
			highSeasRule.setSdHighSeasId(String.valueOf(highSeas.getId()));
			return highSeasRuleService.save(highSeasRule);
		}
	}

	@Override
	public boolean deleteHighSeasRuleListByHighSeasIds(List<Long> ids) {
		List<Long> ruleIdList = new ArrayList<Long>();
		ids.forEach(id ->{
			HighSeasRule highSeasRule = highSeasRuleService.query().eq("sd_high_seas_id",id).one();
			ruleIdList.add(highSeasRule.getId());
		});
		;
		return highSeasRuleService.deleteLogic(ruleIdList);
	}

	/**
	 * 实体复制
	 * copyProperties()
	 *
	 * @param highSeas
	 * @param highSeasRule
	 * @return
	 */
	private HighSeasDTO mergeDataAndHighSeasDto(HighSeas highSeas,HighSeasRule highSeasRule){
		HighSeasDTO highSeasDTO = new HighSeasDTO();
		BeanUtils.copyProperties(highSeas,highSeasDTO);
		return setHighSeasRuleReturnHST(highSeasDTO,highSeasRule);
	}

	/**
	 * 权限实体复制
	 * 因继承业务公告实体类
	 * 不采用copyProperties方法克隆实体
	 * 会造成id status等通用业务字段被覆盖
	 * @param highSeasDTO
	 * @param highSeasRule
	 * @return
	 */
	private HighSeasDTO setHighSeasRuleReturnHST(HighSeasDTO highSeasDTO,HighSeasRule highSeasRule){
		highSeasDTO.setSdHighSeasId(highSeasRule.getSdHighSeasId());
		highSeasDTO.setSdLabelsIdOne(highSeasRule.getSdLabelsIdOne());
		highSeasDTO.setSdLabelsIdTwo(highSeasRule.getSdLabelsIdTwo());
		highSeasDTO.setSdLabelsIdThree(highSeasRule.getSdLabelsIdThree());
		highSeasDTO.setSdHighSeasDays(highSeasRule.getSdHighSeasDays());
		highSeasDTO.setSdHighSeasDaysOne(highSeasRule.getSdHighSeasDaysOne());
		highSeasDTO.setSdHighSeasDaysTwo(highSeasRule.getSdHighSeasDaysTwo());
		highSeasDTO.setSdHighSeasRemindDays(highSeasRule.getSdHighSeasRemindDays());
		highSeasDTO.setSdHighSeasRemindTime(highSeasRule.getSdHighSeasTime());
		highSeasDTO.setSdHighSeasTime(highSeasRule.getSdHighSeasTime());
		highSeasDTO.setSdHighSeasType(highSeasRule.getSdHighSeasType());
		highSeasDTO.setSdHighSeasBanGet(highSeasRule.getSdHighSeasBanGet());
		highSeasDTO.setSdHighSeasBanOn(highSeasRule.getSdHighSeasBanOn());
		highSeasDTO.setSdHighSeasDaysThree(highSeasRule.getSdHighSeasDaysThree());
		return highSeasDTO;
	}

	/**
	 * 权限实体复制
	 * 分离Rule数据
	 *
	 * @param highSeasDTO
	 * @return
	 */
	private HighSeasRule getHighSeasRuleReturnRule(HighSeasDTO highSeasDTO){
		HighSeasRule highSeasRule = new HighSeasRule();
		highSeasRule.setSdHighSeasId(highSeasDTO.getSdHighSeasId());
		highSeasRule.setSdLabelsIdOne(highSeasDTO.getSdLabelsIdOne());
		highSeasRule.setSdLabelsIdTwo(highSeasDTO.getSdLabelsIdTwo());
		highSeasRule.setSdLabelsIdThree(highSeasDTO.getSdLabelsIdThree());
		highSeasRule.setSdHighSeasDays(highSeasDTO.getSdHighSeasDays());
		highSeasRule.setSdHighSeasDaysOne(highSeasDTO.getSdHighSeasDaysOne());
		highSeasRule.setSdHighSeasDaysTwo(highSeasDTO.getSdHighSeasDaysTwo());
		highSeasRule.setSdHighSeasRemindDays(highSeasDTO.getSdHighSeasRemindDays());
		highSeasRule.setSdHighSeasRemindTime(highSeasDTO.getSdHighSeasTime());
		highSeasRule.setSdHighSeasTime(highSeasDTO.getSdHighSeasTime());
		highSeasRule.setSdHighSeasType(highSeasDTO.getSdHighSeasType());
		highSeasRule.setSdHighSeasBanGet(highSeasDTO.getSdHighSeasBanGet());
		highSeasRule.setSdHighSeasBanOn(highSeasDTO.getSdHighSeasBanOn());
		highSeasRule.setSdHighSeasDaysThree(highSeasDTO.getSdHighSeasDaysThree());
		return highSeasRule;
	}

	public R contactsList(Query query) {
		Contacts contacts =new Contacts();
		List<HighSeas> highSeasList = this.list();
		HighSeas highSeasOne = highSeasList.get(0);
		contacts.setSdContactsIsHighSeas(1);
		contacts.setSdContactsHighSeas(String.valueOf(highSeasOne.getId()));
		IPage<Contacts> pages = contactsService.page(Condition.getPage(query), Condition.getQueryWrapper(contacts));
		return R.data(pages);	}
}
