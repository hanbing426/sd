/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.contacts.mapper;

import org.springblade.modules.businessopportunity.entity.BusinessOpportunity;
import org.springblade.modules.contacts.dto.ContactsDTO;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.vo.*;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.modules.note.entity.Note;

import java.util.List;

/**
 * 联系人表 Mapper 接口
 *
 * @author BladeX
 * @since 2020-06-01
 */
public interface ContactsMapper extends BaseMapper<Contacts> {

	/**
	 * 自定义分页
	 *
	 * @param page
	 * @param contacts
	 * @return
	 */
	List<ContactsVO> selectContactsPage(IPage page, ContactsVO contacts);

	/**
	 * 查询返回一条的联系人详细信息数据
	 * @return
	 */
	ContactsDTO getContactsDtoDetail(ContactsVO contacts);

	/**
	 *
	 * @param userId
	 * @param labelId
	 * @param deptId
	 * @param groupId
	 * @param isHighSeas 1查询公海内的0查询不在公海内的
	 * @return
	 */
	List<ContactsListVO> contactsList(String userId,String labelId, String deptId, String groupId,String isHighSeas,String highseasId);

	List<ContactsListVO> contactsHighseasList(String highseasId, String deptId);

	ContactsRemindListVo customerNotFollowedUpFor7DaysAndsevenDayBirthday();

	List<BusinessOpportunity> businessOpportunityList(String contactsId);

	List<Contacts> selectDeptContactsDetail(String deptId);

	List<Note> contactsNoteList(String createUser,String contactsId);

	ContactsDetailVo contactsDetail(String contactsId);

	String customerNotFollowedUpFor7Days();

	String sevenDayBirthday();

	ContactsDetailVo highseasContactsDetail(String contactsId);

	List<ContactsNewCustomer> customerList(String contactsId);

	List<ContactsVO>  getBlackList(IPage page, ContactsVO contacts);

	void addBlackList(String id);

	void removeBlackList(String id);

//	void fillInNewContacts(String userPhone);
}
