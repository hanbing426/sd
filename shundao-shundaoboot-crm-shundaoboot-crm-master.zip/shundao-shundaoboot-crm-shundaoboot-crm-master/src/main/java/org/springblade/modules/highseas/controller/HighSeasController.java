/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.highseas.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import lombok.AllArgsConstructor;
import javax.validation.Valid;

import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.oss.minio.MinioTemplate;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.modules.highseas.dto.HighSeasDTO;
import org.springblade.modules.highseasrule.entity.HighSeasRule;
import org.springblade.modules.highseasrule.service.IHighSeasRuleService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestParam;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.modules.highseas.entity.HighSeas;
import org.springblade.modules.highseas.vo.HighSeasVO;
import org.springblade.modules.highseas.wrapper.HighSeasWrapper;
import org.springblade.modules.highseas.service.IHighSeasService;
import org.springblade.core.boot.ctrl.BladeController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 公海表 控制器
 *
 * @author BladeX
 * @since 2020-05-27
 */
@RestController
@AllArgsConstructor
@RequestMapping("highSeas/highseas")
@Api(value = "公海表", tags = "公海表接口")
public class HighSeasController extends BladeController {

	private IHighSeasService highSeasService;

	private IHighSeasRuleService highSeasRuleService;

	/**
	 * 详情
	 */
	@GetMapping("/detail")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入highSeas")
	public R<HighSeasDTO> detail(HighSeas highSeas) {
		HighSeasDTO highSeasDtoDetail = highSeasService.getHighSeasDtoOne(highSeas);
//		Map<String,Object> highSeassRuleTypeList =highSeasRuleService.getHighSeasRuleList(String.valueOf(highSeas.getId()));
//		HighSeasRule highSeasRuleDetail = highSeasRuleService.query().eq("sd_high_seas_id",highSeas.getId()).one();
//		Map<String,Object> returnData = new HashMap<>();
//		returnData.put("sdHighSeas",highSeasDtoDetail);
//		returnData.put("sdHighSeasRule",highSeasRuleDetail);
		return R.data(highSeasDtoDetail);
	}

	/**
	 * 分页 公海表
	 */
	@GetMapping("/list")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "分页", notes = "传入highSeas")
	public R<IPage<HighSeasVO>> list(HighSeas highSeas, Query query) {
		IPage<HighSeas> pages = highSeasService.page(Condition.getPage(query), Condition.getQueryWrapper(highSeas));
		return R.data(HighSeasWrapper.build().pageVO(pages));
	}


	/**
	 * 自定义分页 公海表
	 */
	@GetMapping("/page")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页", notes = "传入highSeas")
	public R<IPage<HighSeasVO>> page(HighSeasVO highSeas, Query query) {
		IPage<HighSeasVO> pages = highSeasService.selectHighSeasPage(Condition.getPage(query), highSeas);
		return R.data(pages);
	}

	/**
	 * 新增 公海表
	 */
	@PostMapping("/save")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "新增", notes = "传入highSeasDto")
	public R save(@Valid @RequestBody HighSeasDTO highSeasDto) {
		return R.status(highSeasService.highSeasDtoToTwoSave(highSeasDto));
	}

	/**
	 * 修改 公海表
	 */
	@PostMapping("/update")
	@ApiOperationSupport(order = 5)
	@ApiOperation(value = "修改", notes = "传入highSeasDto")
	public R update(@Valid @RequestBody HighSeasDTO highSeasDto) {
		return R.status(highSeasService.highSeasDtoToTwoSave(highSeasDto));
	}

	/**
	 * 新增或修改 公海表
	 */
	@PostMapping("/submit")
	@ApiOperationSupport(order = 6)
	@ApiOperation(value = "新增或修改", notes = "传入highSeasDto")
	public R submit(@Valid @RequestBody HighSeasDTO highSeasDto) {
		return R.status(highSeasService.highSeasDtoToTwoSave(highSeasDto));
	}


	/**
	 * 删除 公海表
	 * 支持批量删除
	 * 并且删除主表附表数据连带逻辑删除
	 */
	@PostMapping("/remove")
	@ApiOperationSupport(order = 7)
	@ApiOperation(value = "逻辑删除", notes = "传入ids")
	public R remove(@ApiParam(value = "主键集合", required = true) @RequestParam String ids) {
		List<Long> idList = Func.toLongList(ids);
		return R.status(highSeasService.deleteLogic(Func.toLongList(ids))&&highSeasService.deleteHighSeasRuleListByHighSeasIds(idList));
	}


}
