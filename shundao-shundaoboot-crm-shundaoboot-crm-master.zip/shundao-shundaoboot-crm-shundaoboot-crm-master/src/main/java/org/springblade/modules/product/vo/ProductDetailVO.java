package org.springblade.modules.product.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class ProductDetailVO {

	/**
	 * id
	 */
	@ApiModelProperty(value = "id")
	private String id;

	/**
	 * 产品名称
	 */
	@ApiModelProperty(value = "产品名称")
	private String sdProductName;
	/**
	 * 产品类型
	 */
	@ApiModelProperty(value = "产品类型")
	private String sdProductType;
	/**
	 * 产品价格
	 */
	@ApiModelProperty(value = "产品价格")
	private BigDecimal sdProductPrice;
	/**
	 * 产品说明
	 */
	@ApiModelProperty(value = "产品说明")
	private String sdProductRemarks;

	@ApiModelProperty(value = "创建人")
	private String createUser;

	@ApiModelProperty(value = "创建时间")
	private Date createTime;

}
