package org.springblade.modules.businessopportunity.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springblade.core.mp.base.BaseEntity;

import java.util.List;


@Data
public class BusinessOpportunityListVO extends BaseEntity {

	/**
	 * 商机名称
	 */
	@ApiModelProperty(value = "商机名称")
	private String sdBusinessOpportunityName;
	/**
	 * 销售金额
	 */
	@ApiModelProperty(value = "销售金额")
	private String sdBusinessOpportunitySaleMoney;
	/**
	 * 所属机构
	 */
	@ApiModelProperty(value = "所属机构")
	private List<String> sdBusinessOpportunityDept;
	/**
	 * 所属联系人
	 */
	@ApiModelProperty(value = "所属联系人")
	private String sdBusinessOpportunityContacts;
	/**
	 * 商机内容
	 */
	@ApiModelProperty(value = "商机内容")
	private String sdBusinessOpportunityNote;
	/**
	 * 商机状态 1：初步接洽 2：需求确定 3：方案/报价 4 ：谈判/合同 5 赢单
	 */
	@ApiModelProperty(value = "商机状态 1：初步接洽 2：需求确定 3：方案/报价 4 ：谈判/合同 5 赢单")
	private Integer sdBusinessOpportunityStatus;

}
