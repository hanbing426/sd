/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.approval.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import lombok.AllArgsConstructor;
import javax.validation.Valid;

import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.modules.approval.mapper.ApprovalMapper;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestParam;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.modules.approval.entity.Approval;
import org.springblade.modules.approval.vo.ApprovalVO;
import org.springblade.modules.approval.wrapper.ApprovalWrapper;
import org.springblade.modules.approval.service.IApprovalService;
import org.springblade.core.boot.ctrl.BladeController;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 审批流程 控制器
 *
 * @author BladeX
 * @since 2020-07-25
 */
@RestController
@AllArgsConstructor
@RequestMapping("approval/approval")
@Api(value = "审批流程", tags = "审批流程接口")
public class ApprovalController extends BladeController {

	private final IApprovalService approvalService;
	/**
	 * 详情
	 */
	@GetMapping("/detail")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入approval")
	public R<ApprovalVO> detail(Approval approval) {
		Approval detail = approvalService.getOne(Condition.getQueryWrapper(approval));
		return R.data(ApprovalWrapper.build().entityVO(detail));
	}

	/**
	 * 分页 审批流程
	 */
	@GetMapping("/list")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "分页", notes = "传入approval")
	public R<IPage<ApprovalVO>> list(Approval approval, Query query) {
		IPage<Approval> pages = approvalService.page(Condition.getPage(query), Condition.getQueryWrapper(approval));
		return R.data(ApprovalWrapper.build().pageVO(pages));
	}

	/**
	 * 分页 审批流程
	 */
	@GetMapping("/allList")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "分页", notes = "传入approval")
	public R<List<Approval>> allList(Approval approval, Query query) {
		List<Approval> pages = approvalService.list(Condition.getQueryWrapper(approval));
		return R.data(pages);
	}

	/**
	 * 自定义分页 审批流程
	 */
	@GetMapping("/page")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页", notes = "传入approval")
	public R<IPage<ApprovalVO>> page(ApprovalVO approval, Query query) {
		IPage<ApprovalVO> pages = approvalService.selectApprovalPage(Condition.getPage(query), approval);
		return R.data(pages);
	}

	/**
	 * 新增 审批流程
	 */
	@PostMapping("/save")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "新增", notes = "传入approval")
	public R save(@Valid @RequestBody Approval approval) {
		return R.status(approvalService.save(approval));
	}

	/**
	 * 修改 审批流程
	 */
	@PostMapping("/update")
	@ApiOperationSupport(order = 5)
	@ApiOperation(value = "修改", notes = "传入approval")
	public R update(@Valid @RequestBody Approval approval) {
		return R.status(approvalService.updateById(approval));
	}

	/**
	 * 新增或修改 审批流程
	 */
	@PostMapping("/submit")
	@ApiOperationSupport(order = 6)
	@ApiOperation(value = "新增或修改", notes = "传入approval")
	public R submit(@Valid @RequestBody Approval approval) {
		return R.status(approvalService.saveOrUpdate(approval));
	}

	/**
	 * 批量新增或修改 审批流程
	 */
	@PostMapping("/listSubmit")
	@ApiOperationSupport(order = 6)
	@ApiOperation(value = "批量新增或修改", notes = "传入approvalList")
	public R listSubmit(@Valid @RequestBody List<Approval> approval) {
		List<Approval> cacheData = approvalService.list();
		cacheData.forEach(item->{
			AtomicBoolean isDelete = new AtomicBoolean(true);//删除开关
			approval.forEach(itemCache->{
//				System.out.println("左:"+item.getId()+"    右:"+itemCache.getId());
				System.out.println("上面:"+itemCache.getId()!=null&& Objects.equals(item.getId(), itemCache.getId()));
				if(itemCache.getId()!=null&& Objects.equals(item.getId(), itemCache.getId())){
					isDelete.set(false);//如果数据库中原本的审核组与传过来的新编辑的审核组有区别即删除掉传过来审核组中ID不为空也就是原本数据库中有前台删除掉的在数据空中也删除掉
				}
			});
			System.out.println("总成:"+isDelete.get());
			if(isDelete.get()){
				approvalService.removeById(item.getId());//逻辑删除
			}//删除暂为逻辑删除

		});
		return R.status(
			approvalService.saveOrUpdateBatch(approval)//上面的操作执行完执行这步批量插入或修改 上面的操作保证了剔除掉ID不为空但数据空中没有的数据
		);
	}

	/**
	 * 删除 审批流程
	 */
	@PostMapping("/remove")
	@ApiOperationSupport(order = 7)
	@ApiOperation(value = "逻辑删除", notes = "传入ids")
	public R remove(@ApiParam(value = "主键集合", required = true) @RequestParam String ids) {
		return R.status(approvalService.deleteLogic(Func.toLongList(ids)));
	}


}
