package org.springblade.modules.contacts.service;

import org.springblade.core.mp.base.BaseService;
import org.springblade.core.tool.api.R;
import org.springblade.modules.businessopportunity.entity.BusinessOpportunity;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.vo.ContactsDetailVo;
import org.springblade.modules.contacts.vo.ContactsListVO;
import org.springblade.modules.contacts.vo.ContactsNewCustomer;
import org.springblade.modules.highseas.entity.HighSeas;
import org.springblade.modules.message.entity.Message;
import org.springblade.modules.note.entity.Note;
import org.springblade.modules.system.entity.User;

import java.util.List;

public interface IphoneContactsDetailService extends BaseService<Contacts> {

	/**
	 * 列表展示 联系人笔记
	 * @param note
	 * @return
	 */
	public R contactsNoteList(Note note);


	List contactsContactsList();

	/**
	 * 联系人移至公海
	 * @param contactsId
	 * @param highSeasId
	 * @return
	 */
	R contactsToHighSeas(String contactsId, String highSeasId);

	/**
	 *联系人转到其他用户
	 */
	public R contactsToUser(String contactsId , String userId, String remarks);

	/**
	 * 联系人添加共享人
	 * @param userId
	 * @param contactsId
	 * @return
	 */
	public R contactsAddSharer(String userId, String contactsId);

	/**
	 * 逻辑删除联系人
	 * @param contacts
	 * @return
	 */
	R deleteContacts(Contacts contacts);


	List<ContactsListVO> getContactsList(String user ,String labelId, String deptId, String groupId,String isHighSeas,String highseasId);


	/**
	 *联系人新建商机
	 */
	R saveBusinessOpportunity( BusinessOpportunity businessOpportunity);

	/**
	 *联系人商机列表
	 */
	List<BusinessOpportunity> BusinessOpportunityList(String contactsId);


	/**
	 * 填写商机
	 * @return
	 */
	R fillInBusinessOpportunity(String contactsId);


	/**
	 * 联系人详情
	 * @return
	 */
	ContactsDetailVo contactsDetail(String contactsId);

	R contactsSaveNote(Note note);

	List<Message> contactsMessage(String contactsId);

	List highSeasList();

	R receiveContacts(Contacts contactsId);

	List<ContactsNewCustomer> customerList(String contactsId);
}
