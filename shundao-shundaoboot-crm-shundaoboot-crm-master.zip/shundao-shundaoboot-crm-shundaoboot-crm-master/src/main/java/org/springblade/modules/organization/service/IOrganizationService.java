package org.springblade.modules.organization.service;

import org.springblade.core.mp.base.BaseService;
import org.springblade.core.tool.api.R;
import org.springblade.modules.system.entity.Dept;

public interface IOrganizationService extends BaseService<Dept> {

	R organizationSelect(String userId );

	R organizationSelectList();


	R organizationSelectDetail(String deptId);

	R saveDept(Dept dept);

	R labelSelectList();

	R groupSelectList();

	R SharerSelectList();

	R postSelectList();
}
