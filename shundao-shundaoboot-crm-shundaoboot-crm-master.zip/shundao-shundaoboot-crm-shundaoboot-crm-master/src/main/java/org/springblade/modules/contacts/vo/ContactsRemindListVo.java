package org.springblade.modules.contacts.vo;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import org.springblade.modules.contacts.entity.Contacts;

import java.util.List;


@Data
@ApiModel(value = "ContactsRemindListVo对象", description = "联系人列表")
public class ContactsRemindListVo
{
	private String customerNotFollowedUpFor7Days;

	private String sevenDayBirthday;
}
