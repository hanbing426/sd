package org.springblade.modules.organization.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.tool.api.R;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.mapper.ContactsMapper;
import org.springblade.modules.contacts.service.IContactsService;
import org.springblade.modules.labels.service.ILabelsService;
import org.springblade.modules.organization.service.IOrganizationService;
import org.springblade.modules.system.entity.Dept;
import org.springblade.modules.system.entity.Role;
import org.springblade.modules.system.entity.Tenant;
import org.springblade.modules.system.entity.User;
import org.springblade.modules.system.mapper.DeptMapper;
import org.springblade.modules.system.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class OrganizationServiceImpl extends BaseServiceImpl<DeptMapper, Dept> implements IOrganizationService {

	@Autowired
	private IUserService userService;

	@Autowired
	private ILabelsService labelsService;

	@Autowired
	private DeptMapper deptMapper;

	@Autowired
	private IContactsService contactsService;

	@Autowired
	private IDeptService deptService;

	@Autowired
	private ContactsMapper contactsMapper;

	@Autowired
	private IPostService postService;

	@Override
	public R organizationSelect(String userId ) {
		List<Dept> deptList = deptMapper.deptCount(userId);
		return R.data(deptList);
	}



	@Override
	public R organizationSelectList() {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.select("id","real_name");
		List<Map<String,String>> list = userService.listMaps(queryWrapper);
		return R.data(list);
	}

	@Override
	public R organizationSelectDetail(String deptId) {
		Dept dept = deptService.getById(deptId);
		Map deptDetail = new HashMap();
		deptDetail.put("dept",dept);
		List<Contacts> contactsList = contactsMapper.selectDeptContactsDetail(deptId);
		deptDetail.put("contactsList",contactsList);
		return R.data(deptDetail);
	}

	@Override
	public R saveDept(Dept dept) {
		return R.data(this.saveOrUpdate(dept));
	}

	@Override
	public R labelSelectList() {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.select("id,sd_label_name");
		List list = labelsService.listMaps(queryWrapper);
		return R.data(list);
	}

	@Override
	public R groupSelectList() {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("dept_category",4);
		queryWrapper.select("id,dept_name");
		List list = deptService.listMaps(queryWrapper);
		return R.data(list);
	}

	@Override
	public R SharerSelectList() {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.select("id,real_name,avatar,phone");
		List list = userService.listMaps(queryWrapper);
		return R.data(list);
	}

	@Override
	public R postSelectList() {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.select("id,post_name");
		List list = postService.listMaps(queryWrapper);
		return R.data(list);
	}


}
