/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.highseasrule.service.impl;

import org.springblade.modules.highseasrule.entity.HighSeasRule;
import org.springblade.modules.highseasrule.vo.HighSeasRuleVO;
import org.springblade.modules.highseasrule.mapper.HighSeasRuleMapper;
import org.springblade.modules.highseasrule.service.IHighSeasRuleService;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *  服务实现类
 *
 * @author BladeX
 * @since 2020-05-27
 */
@Service
public class HighSeasRuleServiceImpl extends BaseServiceImpl<HighSeasRuleMapper, HighSeasRule> implements IHighSeasRuleService {

	@Override
	public IPage<HighSeasRuleVO> selectHighSeasRulePage(IPage<HighSeasRuleVO> page, HighSeasRuleVO highSeasRule) {
		return page.setRecords(baseMapper.selectHighSeasRulePage(page, highSeasRule));
	}

	/**
	 * 弃用
	 * @param highSeasId
	 * @return
	 */
	@Override
	public Map<String, Object> getHighSeasRuleList(String highSeasId) {
		Map<String,Object> highSeasRuleMapList = new HashMap<>();
		List<HighSeasRule> ruleTypeOne = this.query().eq("sd_high_seas_id",highSeasId).eq("sd_high_seas_type",1).list();
		List<HighSeasRule> ruleTypeTwo = this.query().eq("sd_high_seas_id",highSeasId).eq("sd_high_seas_type",2).list();
		List<HighSeasRule> ruleTypeThree = this.query().eq("sd_high_seas_id",highSeasId).eq("sd_high_seas_type",3).list();
		List<HighSeasRule> ruleTypeFour = this.query().eq("sd_high_seas_id",highSeasId).eq("sd_high_seas_type",4).list();
		List<HighSeasRule> ruleTypeFive = this.query().eq("sd_high_seas_id",highSeasId).eq("sd_high_seas_type",5).list();
		highSeasRuleMapList.put("One",ruleTypeOne);
		highSeasRuleMapList.put("Two",ruleTypeTwo);
		highSeasRuleMapList.put("Three",ruleTypeThree);
		highSeasRuleMapList.put("Four",ruleTypeFour);
		highSeasRuleMapList.put("Five",ruleTypeFive);
		return highSeasRuleMapList;
	}

}
