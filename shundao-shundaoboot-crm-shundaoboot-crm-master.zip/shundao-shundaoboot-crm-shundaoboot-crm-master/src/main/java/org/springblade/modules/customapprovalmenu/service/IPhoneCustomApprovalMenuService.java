package org.springblade.modules.customapprovalmenu.service;


import org.springblade.core.mp.base.BaseService;
import org.springblade.core.tool.api.R;
import org.springblade.modules.customapprovalmenu.dto.CustomApprovalMenuList;
import org.springblade.modules.customapprovalmenu.entity.CustomApprovalMenu;
import org.springblade.modules.returnMoney.entity.ReturnMoney;

public interface IPhoneCustomApprovalMenuService extends BaseService<CustomApprovalMenu> {


	CustomApprovalMenuList saveList(String menuId);

	R approvalList(String status);

	R updateApprovalStatus(ReturnMoney returnMoney , Integer status);

	R approvalDetail(String id);
}
