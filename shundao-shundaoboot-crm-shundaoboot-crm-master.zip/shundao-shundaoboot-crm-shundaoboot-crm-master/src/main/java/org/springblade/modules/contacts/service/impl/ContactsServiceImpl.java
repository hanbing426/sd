/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.contacts.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.segments.MergeSegments;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.tool.api.R;
import org.springblade.modules.contacts.dto.ContactsDTO;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.vo.ContactsVO;
import org.springblade.modules.contacts.mapper.ContactsMapper;
import org.springblade.modules.contacts.service.IContactsService;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.modules.contract.entity.Contract;
import org.springblade.modules.contract.service.IContractService;
import org.springblade.modules.enclosure.entity.Enclosure;
import org.springblade.modules.enclosure.service.IEnclosureService;
import org.springblade.modules.labels.entity.Labels;
import org.springblade.modules.labels.service.ILabelsService;
import org.springblade.modules.note.entity.Note;
import org.springblade.modules.note.service.INoteService;
import org.springblade.modules.remarks.entity.Remarks;
import org.springblade.modules.remarks.service.IRemarksService;
import org.springblade.modules.returnMoney.entity.ReturnMoney;
import org.springblade.modules.returnMoney.service.IReturnMoneyService;
import org.springblade.modules.system.entity.Dept;
import org.springblade.modules.system.entity.Role;
import org.springblade.modules.system.service.IDeptService;
import org.springblade.modules.system.service.IRoleService;
import org.springblade.modules.system.vo.DeptVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.core.metadata.IPage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 联系人表 服务实现类
 *
 * @author BladeX
 * @since 2020-06-01
 */
@Service

public class ContactsServiceImpl extends BaseServiceImpl<ContactsMapper, Contacts> implements IContactsService {

	@Autowired
	private IDeptService deptService;


	@Override
	public IPage<ContactsVO> selectContactsPage(IPage<ContactsVO> page, ContactsVO contacts) {
		return page.setRecords(baseMapper.selectContactsPage(page, contacts));
	}

	@Override
	public IPage<ContactsVO> getBlackList(IPage<ContactsVO> page, ContactsVO contacts) {
		return page.setRecords(baseMapper.getBlackList(page, contacts));
	}

	@Override
	public void addBlackList(String id) {
		baseMapper.addBlackList(id);
	}

	@Override
	public void removeBlackList(String id) {
		baseMapper.removeBlackList(id);
	}

	@Override
	public ContactsDTO getContactsDetail(ContactsVO contacts) {
		ContactsDTO contactsDTO  = baseMapper.getContactsDtoDetail(contacts);
		return contactsDTO;
	}




}
