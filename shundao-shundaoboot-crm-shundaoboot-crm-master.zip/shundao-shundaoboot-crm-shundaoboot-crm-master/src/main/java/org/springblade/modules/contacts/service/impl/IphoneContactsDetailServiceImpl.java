package org.springblade.modules.contacts.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Assert;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.secure.utils.SecureUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.StringUtil;
import org.springblade.modules.businessopportunity.entity.BusinessOpportunity;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.mapper.ContactsMapper;
import org.springblade.modules.businessopportunity.service.IPhoneBusinessOpportunityService;
import org.springblade.modules.contacts.service.IContactsService;
import org.springblade.modules.contacts.service.IphoneContactsDetailService;
import org.springblade.modules.contacts.vo.ContactsDetailVo;
import org.springblade.modules.contacts.vo.ContactsListVO;
import org.springblade.modules.contacts.vo.ContactsNewCustomer;
import org.springblade.modules.highseas.entity.HighSeas;
import org.springblade.modules.highseas.service.IHighSeasService;
import org.springblade.modules.message.entity.Message;
import org.springblade.modules.message.service.IMessageService;
import org.springblade.modules.note.entity.Note;
import org.springblade.modules.note.service.INoteService;
import org.springblade.modules.remarks.entity.Remarks;
import org.springblade.modules.remarks.service.IRemarksService;
import org.springblade.modules.system.entity.User;
import org.springblade.modules.system.service.IDeptService;
import org.springblade.modules.system.service.IDictBizService;
import org.springblade.modules.system.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import springfox.documentation.service.Contact;

import java.util.List;

@Service
public class IphoneContactsDetailServiceImpl extends BaseServiceImpl<ContactsMapper, Contacts> implements IphoneContactsDetailService {



	@Autowired
	private IRemarksService remarksService;


	@Autowired
	private ContactsMapper contactsMapper;

	@Autowired
	private IMessageService messageService;

	@Autowired
	private IPhoneBusinessOpportunityService businessOpportunityService;

	@Autowired
	private IUserService userService;

	@Autowired
	private IDictBizService dictBizService;

	@Autowired
	private IContactsService contactsService;

	@Autowired
	private IDeptService deptService;

	@Autowired
	private INoteService noteService;

	@Autowired
	private IHighSeasService highSeasService;

	@Override
	public R contactsToHighSeas(String contactsId, String highSeasId) {
		Contacts contacts = contactsService.getById(contactsId);
		HighSeas highSeas = highSeasService.getById(highSeasId);
		Assert.notNull(contacts, "错误:错误的联系人ID，未找到该联系人！", new Object[0]);
		Assert.notNull(highSeas, "错误:错误的公海ID，未找到该公海！!", new Object[0]);
		Message message = new Message();
		String note = "将联系人"+contacts.getSdContactsName()+"移至"+highSeas.getSdHighSeasName();
		message.setSdOperationText(note);
		message.setSdIsRead(0);
		message.setSdUserId(String.valueOf(contacts.getCreateUser()));
		message.setSdMessageType(0);
		message.setSdContactsId(contactsId);
		messageService.saveOrUpdate(message);
		contacts.setSdContactsIsHighSeas(1);
		contacts.setSdContactsHighSeas(String.valueOf(highSeas.getId()));
		contacts.setCreateUser(-1l);
		contacts.setSdContactsShareUser("-1");
		return R.status(this.saveOrUpdate(contacts));
	}

	@Override
	public R contactsToUser(String contactsId,String userId, String remarks) {
		Contacts contacts = contactsService.getById(contactsId);
		User user = userService.getById(userId);
		Assert.notNull(contacts, "错误:错误的联系人ID，未找到该联系人", new Object[0]);
		Assert.notNull(user, "错误:错误的用户ID，未找到该用户!", new Object[0]);
		contacts.setCreateUser(user.getId());
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("sd_contacts_id",contactsId);
		Remarks rs = remarksService.getOne(queryWrapper);
		rs.setSdRemarks(rs.getSdRemarks()+"|"+remarks);
		rs.setSdContactsId(contactsId);
		remarksService.saveOrUpdate(rs);
		//存储消息列表
		Message message = new Message();
		message.setSdIsRead(0);
		String note = "将联系人"+contacts.getSdContactsName()+"转移给"+user.getName();
		message.setSdOperationText(note);
		message.setSdUserId(String.valueOf(contacts.getCreateUser()));
		message.setSdMessageType(0);
		message.setSdContactsId(contactsId);
		messageService.saveOrUpdate(message);
		Message messageTow = new Message();
		messageTow.setSdIsRead(0);
		User userOne = userService.getById(contacts.getCreateUser());
		String noteTow = SecureUtil.getUser().getUserName()+"将联系人"+contacts.getSdContactsName()+"转移给你";
		messageTow.setSdOperationText(noteTow);
		messageTow.setSdUserId(String.valueOf(userOne.getId()));
		messageTow.setSdMessageType(0);
		message.setSdContactsId(contactsId);
		messageService.saveOrUpdate(messageTow);
		return R.status(this.saveOrUpdate(contacts));
	}

	@Override
	public R contactsAddSharer(String userId, String contactsId) {
		Contacts contacts = contactsService.getById(contactsId);
		User user = userService.getById(userId);
		Assert.notNull(contacts, "错误:错误的联系人ID，未找到该联系人", new Object[0]);
		Assert.notNull(user, "错误:错误的用户ID，未找到该用户!", new Object[0]);
		contacts.setSdContactsShareUser(contacts.getSdContactsShareUser()+","+user.getId());
		//存储消息列表
		Message message = new Message();
		message.setSdIsRead(0);
		message.setSdUserId(String.valueOf(contacts.getCreateUser()));
		String note = "将联系人"+contacts.getSdContactsName()+"共享给"+user.getName();
		message.setSdOperationText(note);
		message.setSdMessageType(0);
		message.setSdContactsId(contactsId);
		messageService.saveOrUpdate(message);
		Message messageTow = new Message();
		messageTow.setSdIsRead(0);
		messageTow.setSdUserId(String.valueOf(user.getId()));
		String noteTow =SecureUtil.getUser().getUserName()+"将联系人"+contacts.getSdContactsName()+"共享给你";
		messageTow.setSdOperationText(noteTow);
		messageTow.setSdMessageType(0);
		message.setSdContactsId(contactsId);
		messageService.saveOrUpdate(messageTow);
		return R.status(this.saveOrUpdate(contacts));
	}

	@Override
	public R deleteContacts(Contacts contacts) {
		Message message = new Message();
		message.setSdUserId(String.valueOf(contacts.getCreateUser()));
		String note = "将联系人"+contacts.getSdContactsName()+"删除";
		message.setSdOperationText(note);
		message.setSdIsRead(0);
		message.setSdMessageType(0);
		message.setSdContactsId(contacts.getId().toString());
		messageService.save(message);
		return R.status(this.removeById(contacts));
	}

	@Override
	public List<ContactsListVO> getContactsList(String userId,String labelId, String deptId, String groupId,String isHighSeas,String highseasId) {
		return contactsMapper.contactsList(userId,labelId, deptId, groupId,isHighSeas,highseasId);
	}

	@Override
	public R saveBusinessOpportunity(BusinessOpportunity businessOpportunity) {
		Message message = new Message();
		message.setSdIsRead(0);
		String userId = String.valueOf(SecureUtil.getUser().getUserId());
		//加入消息日志
		message.setSdOperationText(SecureUtil.getUser().getUserName()+"新建商机:"+businessOpportunity.getSdBusinessOpportunityName());
		message.setSdUserId(userId);
		String sdBusinessOpportunityContacts = businessOpportunity.getSdBusinessOpportunityContacts();
		message.setSdContactsId(sdBusinessOpportunityContacts);
		message.setSdMessageType(0);
		messageService.save(message);
		return R.status(businessOpportunityService.saveOrUpdate(businessOpportunity));
	}

	@Override
	public List<BusinessOpportunity> BusinessOpportunityList(String contactsId) {
		List<BusinessOpportunity> businessOpportunities = contactsMapper.businessOpportunityList(contactsId);
		return businessOpportunities;
	}

	@Override
	public R fillInBusinessOpportunity(String contactsId) {
			QueryWrapper queryWrapper = new QueryWrapper();
			queryWrapper.eq("parent_id",1278954359147966465l);
			queryWrapper.select("dic_key","dict_value");
			List list = dictBizService.listMaps(queryWrapper);
			return R.data(list);
	}

	/**
	 * 联系人详情
	 * @param contactsId
	 * @return
	 */
	@Override
	public ContactsDetailVo contactsDetail(String contactsId) {
		if(StringUtil.isNotBlank(contactsId)){
			QueryWrapper isHighseasQueryWrapper = new QueryWrapper();
			isHighseasQueryWrapper.eq("sd_contacts_is_high_seas",1);
			isHighseasQueryWrapper.eq("id",contactsId);
			List isHighseas = contactsService.list(isHighseasQueryWrapper);
			if(isHighseas.size()>0){
				ContactsDetailVo contactsDetailVo = contactsMapper.highseasContactsDetail(contactsId);
				return contactsDetailVo;
			}else {
				ContactsDetailVo contactsDetailVo = contactsMapper.contactsDetail(contactsId);
				return contactsDetailVo;
			}
		}else {
			return null;
		}

	}

	@Override
	public R contactsSaveNote(Note note) {
		return R.data(noteService.saveOrUpdate(note));
}

	@Override
	public List<Message> contactsMessage(String contactsId) {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("sd_contacts_id",contactsId);
		queryWrapper.eq("sd_message_type",0);
		return  messageService.list(queryWrapper);
	}

	@Override
	public List highSeasList() {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.select("id,sd_high_seas_name");
		List list = highSeasService.listMaps(queryWrapper);
		return list;
	}


	/**
	 * 公海领取联系人
	 * @param contacts
	 * @return
	 */
	@Override
	public R receiveContacts(Contacts contacts) {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("id",contacts.getId());
		List <Contacts> list = contactsService.list(queryWrapper);
		if (list.size()>0){
			Message message = new Message();
			String msg = "领取了联系人:"+ list.get(0).getSdContactsName();
			message.setSdOperationText(msg);
			message.setSdIsRead(0);
			message.setSdUserId(String.valueOf(SecureUtil.getUserId()));
			message.setSdMessageType(0);
			message.setSdContactsId(contacts.getId().toString());
			messageService.saveOrUpdate(message);
			Message messageTow = new Message();
			String msgTow = "联系人:"+list.get(0).getSdContactsName()+"被用户"+SecureUtil.getUserName()+"领取";
			messageTow.setSdUserId(String.valueOf(SecureUtil.getUserId()));
			messageTow.setSdIsRead(0);
			messageTow.setSdOperationText(msgTow);
			messageTow.setSdContactsId(String.valueOf(contacts.getId()));
			messageTow.setSdMessageType(0);
			Long userId = SecureUtil.getUserId();
			contacts.setCreateUser(userId);
			contacts.setSdContactsIsHighSeas(0);
			contactsService.updateById(contacts);
			return R.success("成功");
		}else {
			return R.fail("未找到该联系人");
		}
	}

	@Override
	public List<ContactsNewCustomer> customerList(String contactsId) {
		return contactsMapper.customerList(contactsId);
	}


	/**
	 * 笔记联系人展示
	 * @return
	 */
	@Override
	public List contactsContactsList() {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("sd_contacts_is_high_seas",0);
		queryWrapper.select("sd_contacts_name","id");
		List list = contactsService.listMaps(queryWrapper);
		return list;
	}

	@Override
	public R contactsNoteList(Note note) {
		String userId = String.valueOf(SecureUtil.getUser().getUserId());
		List<Note> notes = contactsMapper.contactsNoteList(userId, note.getSdNoteByContacts());
		return R.data(notes);
	}

}
