package org.springblade.modules.returnMoney.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Map;

@Data
public class ReturnMoneyListVO {

	private static final long serialVersionUID = 1L;

	private Long id;

	/**
	 * 本次回款金额
	 */
	@ApiModelProperty(value = "本次回款金额")
	private BigDecimal sdReturnMoney;

	/**
	 * 回款时间
	 */
	@ApiModelProperty(value = "回款时间")
	private Date sdReturnMoneyTime;

	/**
	 * 付款方式
	 */
	@ApiModelProperty(value = "付款方式")
	private String sdReturnMoneyType;
	/**
	 * 回款备注
	 */
	@ApiModelProperty(value = "回款备注")
	private String sdReturnMoneyRemarks;
	/**
	 * 回款所属联系人
	 */
	@ApiModelProperty(value = "回款所属联系人")
	private Map sdReturnMoneyContactsId;
	/**
	 * 回款所属公司
	 */
	@ApiModelProperty(value = "回款所属公司")
	private Map sdReturnMoneyDeptId;
	/**
	 * 自定义表单数据ID
	 */
	@ApiModelProperty(value = "自定义表单数据ID")
	private String sdReturnMoneyCustomId;

	private Date createTime;


}
