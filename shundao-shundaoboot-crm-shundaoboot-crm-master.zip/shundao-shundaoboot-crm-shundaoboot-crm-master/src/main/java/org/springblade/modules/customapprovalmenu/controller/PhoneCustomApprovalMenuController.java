package org.springblade.modules.customapprovalmenu.controller;


import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import oracle.jdbc.proxy.annotation.Post;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.tool.api.R;
import org.springblade.modules.customapprovalmenu.entity.CustomApprovalMenu;
import org.springblade.modules.customapprovalmenu.service.IPhoneCustomApprovalMenuService;
import org.springblade.modules.customapprovalmenu.vo.CustomApprovalMenuVO;
import org.springblade.modules.customapprovalmenu.wrapper.CustomApprovalMenuWrapper;
import org.springblade.modules.returnMoney.entity.ReturnMoney;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping("/customapprovalmenu")
@Api(value = "客户端自定义审批菜单", tags = "自定义审批菜单接口")
public class PhoneCustomApprovalMenuController {

	@Autowired
	private IPhoneCustomApprovalMenuService phoneCustomApprovalMenuService;

	/**
	 * 按钮列表
	 */
	@GetMapping("/menuList")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入customApprovalMenu")
	public R menuList() {
		return R.data(phoneCustomApprovalMenuService.list());
	}


	/**
	 * 展示审核分组内容
	 */
	@GetMapping("/saveList")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "展示审核分组内容")
	public R saveList(String menuId) {
		return R.data(phoneCustomApprovalMenuService.saveList(menuId));
	}

	/**
	 * 根据当前审批人列表展示回款
	 */
	@GetMapping("/approvalList")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "回款列表")
	public R approvalList(String status) {
		return phoneCustomApprovalMenuService.approvalList(status);
	}


	/**
	 * 当前审批单详情
	 */
	@GetMapping("/approvalDetail")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "添加展示")
	public R approvalDetail(String id) {
		return phoneCustomApprovalMenuService.approvalDetail(id);
	}


	/**
	 * 同意或者驳回审批
	 */
	@PostMapping("/updateApprovalStatus")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "同意或者驳回审批")
	public R updateApprovalStatus(ReturnMoney returnMoney , Integer status) {
		return phoneCustomApprovalMenuService.updateApprovalStatus(returnMoney,status);
	}



}
