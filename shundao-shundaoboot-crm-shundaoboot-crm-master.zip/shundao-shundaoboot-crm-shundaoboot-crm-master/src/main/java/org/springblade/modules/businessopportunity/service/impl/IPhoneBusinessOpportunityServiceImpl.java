package org.springblade.modules.businessopportunity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.secure.utils.SecureUtil;
import org.springblade.core.tool.api.R;
import org.springblade.modules.businessopportunity.dto.BusinessOpportunityDetailDTO;
import org.springblade.modules.businessopportunity.entity.BusinessOpportunity;
import org.springblade.modules.businessopportunity.mapper.BusinessOpportunityMapper;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.service.IContactsService;
import org.springblade.modules.businessopportunity.service.IPhoneBusinessOpportunityService;
import org.springblade.modules.message.entity.Message;
import org.springblade.modules.message.service.IMessageService;
import org.springblade.modules.system.service.IDeptService;
import org.springblade.modules.system.service.IDictBizService;
import org.springblade.modules.system.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class IPhoneBusinessOpportunityServiceImpl extends BaseServiceImpl<BusinessOpportunityMapper, BusinessOpportunity> implements IPhoneBusinessOpportunityService {

	@Autowired
	private BusinessOpportunityMapper businessOpportunityMapper;


	@Autowired
	private IDeptService deptService;

	@Autowired
	private IContactsService contactsService;

	@Autowired
	private IDictBizService dictBizService;

	@Autowired
	private IMessageService messageService;

	@Autowired
	private IUserService userService;

	@Override
	public List<BusinessOpportunity> businessOpportunityRuleSelect( String contactsId) {
		String userId = String.valueOf(SecureUtil.getUser().getUserId());
		List<BusinessOpportunity> businessOpportunities = businessOpportunityMapper.businessOpportunityRuleSelect(contactsId,userId);
		return businessOpportunities;
	}

	@Override
	public Map BusinessOpportunityRule() {
		QueryWrapper queryWrapperOne = new QueryWrapper();
		queryWrapperOne.eq("sd_contacts_is_high_seas",0);
		queryWrapperOne.select("id","sd_contacts_name");
		List<Contacts> contactsList = contactsService.listMaps(queryWrapperOne);
		Map map = new HashMap();
		map.put("contactsList",contactsList);
		return map;
	}

	@Override
	public BusinessOpportunityDetailDTO BusinessOpportunityDetail(String id) {
		String userId = String.valueOf(SecureUtil.getUserId());
		BusinessOpportunityDetailDTO businessOpportunity = businessOpportunityMapper.BusinessOpportunityDetail(id, userId,SecureUtil.getTenantId());
		return businessOpportunity;
	}

	@Override
	public Map fillInBusinessOpportunity() {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("sd_contacts_is_high_seas",0);
		queryWrapper.select("id,sd_contacts_name");
		List list = contactsService.listMaps(queryWrapper);
		QueryWrapper queryWrapperTow = new QueryWrapper();
		queryWrapperTow.eq("parent_id",1278954359147966465l);
		queryWrapperTow.select("dict_key","dict_value");
		List listTow = dictBizService.listMaps(queryWrapperTow);
		QueryWrapper queryWrapperThree = new QueryWrapper();
		queryWrapperThree.select("id,dept_name");
		queryWrapperThree.eq("dept_category",1);
		List listThree = deptService.listMaps(queryWrapperThree);
		Map map = new HashMap();
		map.put("contactsList",list);
		map.put("statusList",listTow);
		map.put("deptList",listThree);
		return map;
	}

	@Override
	public R saveBusinessOpportunity(BusinessOpportunity businessOpportunity) {
		Message message = new Message();
		message.setSdIsRead(0);
		String userId = String.valueOf(SecureUtil.getUser().getUserId());
		//加入消息日志
		message.setSdOperationText(SecureUtil.getUser().getUserName()+"新建商机:"+businessOpportunity.getSdBusinessOpportunityName());
		message.setSdUserId(userId);
		message.setSdMessageType(0);
		messageService.saveOrUpdate(message);
		return R.status(this.saveOrUpdate(businessOpportunity));
	}
}
