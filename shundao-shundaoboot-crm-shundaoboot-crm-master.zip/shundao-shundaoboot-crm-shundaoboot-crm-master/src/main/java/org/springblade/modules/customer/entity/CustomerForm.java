/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.customer.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import org.springblade.core.mp.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 实体类
 *
 * @author BladeX
 * @since 2020-06-15
 */
@Data
@TableName("sd_customer_form")
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "CustomerForm对象", description = "CustomerForm对象")
public class CustomerForm extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/**
	* 表单名称
	*/
		@ApiModelProperty(value = "表单名称")
		private String customerFormName;
	/**
	* 反馈数量
	*/
		@ApiModelProperty(value = "反馈数量")
		private Long customerFormNum;
	/**
	* 头部图片
	*/
		@ApiModelProperty(value = "头部图片")
		private String customerFormTitelImg;
	/**
	* 尾部图片
	*/
		@ApiModelProperty(value = "尾部图片")
		private String customerFormEndImg;
	/**
	* 标题
	*/
		@ApiModelProperty(value = "标题")
		private String customerFormTitel;
	/**
	* 表单简介说明富文本
	*/
		@ApiModelProperty(value = "表单简介说明富文本")
		private String customerFormRichText;
	/**
	* 表单提交后显示
	*/
		@ApiModelProperty(value = "表单提交后显示")
		private String customerFormSubmitSuccess;
	/**
	* 关联标签
	*/
		@ApiModelProperty(value = "关联标签")
		private String customerFormLabelsIds;
	/**
	* 表单HTML
	*/
		@ApiModelProperty(value = "表单HTML")
		private String customerFormHtml;


}
