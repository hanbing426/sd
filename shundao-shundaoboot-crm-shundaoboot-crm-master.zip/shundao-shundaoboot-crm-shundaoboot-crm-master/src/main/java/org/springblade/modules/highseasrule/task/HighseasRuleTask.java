package org.springblade.modules.highseasrule.task;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronTrigger;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
@Slf4j
public class HighseasRuleTask implements SchedulingConfigurer {

	private List<HighseasRuleData> highseasruleDataList= new ArrayList<>();
	private List<String> dateStringList = new ArrayList<>();

	/**
	 * 实现
	 * @param scheduledTaskRegistrar
	 */
	@Override
	public void configureTasks(ScheduledTaskRegistrar scheduledTaskRegistrar) {
		scheduledTaskRegistrar.addTriggerTask(doTask(), getTrigger());
	}

	/**
	 * 业务触发器
	 * @return
	 */
	private Trigger getTrigger() {
		return new Trigger() {
			@Override
			public Date nextExecutionTime(TriggerContext triggerContext) {
				// 触发器
				CronTrigger trigger = new CronTrigger("0/10 * * * * ? ");
				return trigger.nextExecutionTime(triggerContext);
			}
		};
	}

	/**
	 * 业务方法
	 * @return
	 */
	private Runnable doTask() {
		return new Runnable() {
			@Override
			public void run() {
				SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				// 业务逻辑

				log.info(",时间为:" + simpleDateFormat.format(new Date()));
			}
		};
	}


}
