package org.springblade.modules.contacts.controller;

import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springblade.core.boot.ctrl.BladeController;
import org.springblade.core.tool.api.R;
import org.springblade.modules.businessopportunity.entity.BusinessOpportunity;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.service.IphoneContactsDetailService;
import org.springblade.modules.customerdata.service.ICustomerFormDataService;
import org.springblade.modules.highseas.entity.HighSeas;
import org.springblade.modules.note.entity.Note;
import org.springblade.modules.system.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
	@RequestMapping("/phoneContactsDetail/phoneContactsDetail")
@Api(value = "后端联系人详情", tags = "联系人详情接口")
//@PreAuth(AuthConstant.PERMISSION_ALL)
public class PhoneContactsDetailController extends BladeController {


	@Autowired
	private IphoneContactsDetailService iphoneContactsDetailService;
	@Autowired
	private ICustomerFormDataService customerFormDataService;




	/**
	 * 联系人详情
	 */
	@GetMapping("/contactsDetail")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "联系人详情")
	public R contactsDetail(String contactsId)	 {
		return R.data(iphoneContactsDetailService.contactsDetail(contactsId));
	}


	/**
	 * 列表展示 笔记联系人条件
	 */
	@GetMapping("/contactsContactsList")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "笔记联系人条件")
	public R contactsContactsList()	 {
		return R.data(iphoneContactsDetailService.contactsContactsList());
	}

	/**
	 * 列表展示 联系人笔记
	 */
	@GetMapping("/contactsNoteList")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "展示联系人笔记")
	public R contactsNoteList(Note note){
		return iphoneContactsDetailService.contactsNoteList(note);
	}


	/**
	 * 联系人详情 新建笔记
	 */
	@PostMapping("/contactsSaveNote")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = " 联系人详情新建笔记")
	public R contactsSaveNote(Note note){
		return iphoneContactsDetailService.contactsSaveNote(note);
	}

	/**
	 *联系人转移 公海
	 */
	@PostMapping("/contactsToHighSeas")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "联系人转移公海", notes = "传入联系人，公海")
	public R contactsToHighSeas(String contactsId, String highSeasId){
		return iphoneContactsDetailService.contactsToHighSeas(contactsId,highSeasId);
	}

	/**
	 *联系人转移 其他用户
	 */
	@PostMapping("/contactsToUser")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "联系人转移其他人", notes = "传入contacts，转移前用户，将转移用户id ，备注信息")
	public R contactsToUser(String contactsId ,String userId, String remarks){
		return iphoneContactsDetailService.contactsToUser(contactsId,userId,remarks);
	}

	/**
	 *联系人添加 共享
	 */
	@PostMapping("/contactsAddSharer")
	@ApiOperationSupport(order = 5)
	@ApiOperation(value = "联系人添加共享", notes = "传入contacts,用户ID")
	public R contactsAddSharer(String userId , String contactsId){
		return iphoneContactsDetailService.contactsAddSharer(userId,contactsId);
	}

	/**
	 * 逻辑删除 联系人
	 */
	@PostMapping("/deleteContacts")
	@ApiOperationSupport(order = 6)
	@ApiOperation(value = "逻辑删除联系人", notes = "传入联系人")
	public R deleteContacts(Contacts contacts){
		return iphoneContactsDetailService.deleteContacts(contacts);
	}


	/**
	 * 填写商机
	 */
	@GetMapping("/fillInBusinessOpportunity")
	@ApiOperationSupport(order = 7)
	@ApiOperation(value = "商机填写")
	public R fillInBusinessOpportunity(String ContactsId)	 {
		return iphoneContactsDetailService.fillInBusinessOpportunity(ContactsId);
	}



	/**
	 *插入商机
	 */
	@PostMapping("/saveBusinessOpportunity")
	@ApiOperationSupport(order = 8)
	@ApiOperation(value = "联系人新建或者修改商机", notes = "传入商机对象")
	public R saveBusinessOpportunity(BusinessOpportunity businessOpportunity){
		return iphoneContactsDetailService.saveBusinessOpportunity(businessOpportunity);
	}

	/**
	 *联系人商机展示
	 */
	@GetMapping("/businessOpportunityList")
	@ApiOperationSupport(order = 9)
	@ApiOperation(value = "联系人商机展示", notes = "传入联系人对象")
	public R BusinessOpportunityList(String contactsId){
		return R.data(iphoneContactsDetailService.BusinessOpportunityList(contactsId));
	}


	/**
	 *联系人操作日志
	 */
	@GetMapping("/contactsMessage")
	@ApiOperationSupport(order = 10)
	@ApiOperation(value = "联系人操作日志", notes = "传入联系人对象")
	public R contactsMessage(String contactsId){
		return R.data(iphoneContactsDetailService.contactsMessage(contactsId));
	}

	/**
	 *公海列表 转移到公海使用
	 */
	@GetMapping("/highSeasList")
	@ApiOperationSupport(order = 10)
	@ApiOperation(value = "转移到公海使用", notes = "传入联系人对象")
	public R highSeasList(){
		return R.data(iphoneContactsDetailService.highSeasList());
	}

	/**
	 * 领取联系人
	 */
	@PostMapping("/receiveContacts")
	@ApiOperationSupport(order = 11)
	@ApiOperation(value = "领取联系人")
	public R receiveContacts(Contacts contactsId)	 {
		return R.data(iphoneContactsDetailService.receiveContacts(contactsId));
	}

	/**
	 * 自定义表单列表
	 */
	@GetMapping("/customerList")
	@ApiOperationSupport(order = 10)
	@ApiOperation(value = "自定义表单数据列表", notes = "联系人ID")
	public R customerList(String contactsId){
		return R.data(iphoneContactsDetailService.customerList(contactsId));
	}

	/**
	 * 自定义表单列表
	 */
	@GetMapping("/customerDetail")
	@ApiOperationSupport(order = 11)
	@ApiOperation(value = "自定义表单数据详情", notes = "传入表单详情ID")
	public R customerDetail(String formDataId){
		return R.data(customerFormDataService.getById(formDataId));
	}
}
