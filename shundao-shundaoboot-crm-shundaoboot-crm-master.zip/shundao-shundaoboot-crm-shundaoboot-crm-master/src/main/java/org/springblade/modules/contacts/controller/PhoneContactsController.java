package org.springblade.modules.contacts.controller;


import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springblade.core.boot.ctrl.BladeController;
import org.springblade.core.secure.BladeUser;
import org.springblade.core.secure.annotation.PreAuth;
import org.springblade.core.secure.utils.SecureUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.constant.RoleConstant;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.service.IPhoneContactsService;
import org.springblade.modules.contacts.service.IphoneContactsDetailService;
import org.springblade.modules.contacts.vo.ContactsRemindListVo;
import org.springblade.modules.enclosure.entity.Enclosure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@RequestMapping("/phoneContacts/phoneContacts")
@Api(value = "后端联系人表", tags = "联系人表接口")
//@PreAuth(RoleConstant.HAS_ROLE_USER)
public class PhoneContactsController extends BladeController {

	@Autowired
	private IPhoneContactsService phoneContactsService;

	@Autowired
	private IphoneContactsDetailService iphoneContactsDetailService;

	/**
	 * 列表展示 联系人表
	 */
	@GetMapping("/contactsList")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "查询所有联系人" , notes = "传入用户ID userRegisterId，标签ID，机构ID，群组ID")
	public R contactsList(String labelId, String deptId, String groupId,String isHighSeas,String highseasId) {
		String userId = String.valueOf(SecureUtil.getUser().getUserId());
		return R.data(iphoneContactsDetailService.getContactsList(userId,labelId,deptId,groupId,isHighSeas,highseasId));
	}

	/**
	 * 搜索 联系人表
	 */
	/*@PostMapping("/selectContacts")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "查询符合筛选条件联系人", notes = "传入标签ID，机构ID，角色ID")
	public R selectContacts(Map<String,String> map) {
	}*/

	/**
	 * 搜索 联系人表规则
	 */
	@GetMapping("/selectContactsRule")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "查询联系人规则")
	public R selectContactsRule() {
		return phoneContactsService.selectContactsRule();
	}

	/**
	 * 新增 联系人表
	 */
	@PostMapping("/saveContacts")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "新建联系人", notes = "传入联系人，附件，备注，头像连接")
	public R saveContacts(Contacts contacts, String enclosure, String remarks) {
		return phoneContactsService.saveContacts(contacts, enclosure, remarks);
	}

	/**
	 *查询所有公海联系人
	 */
	@GetMapping("/contactsHighseasList")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "查询所有公海联系人" , notes = "传入公海ID，机构ID")
	public R contactsHighseasList(String highseasId ,String deptId) {
		return R.data(phoneContactsService.contactsHighseasList(highseasId,deptId));
	}


	/**
	 *代办列表
	 */
	@GetMapping("/contactRemindList")
	@ApiOperationSupport(order = 5)
	@ApiOperation(value = "代办联系人查询")
	public R contactRemindList(){
		ContactsRemindListVo contactsRemindListVo = phoneContactsService.contactAgencyList();
		return R.data(contactsRemindListVo);
	}
}
