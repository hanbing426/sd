/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.contacts.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import lombok.AllArgsConstructor;
import javax.validation.Valid;

import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.modules.contacts.dto.ContactsDTO;
import org.springblade.modules.labels.service.ILabelsService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestParam;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.vo.ContactsVO;
import org.springblade.modules.contacts.service.IContactsService;
import org.springblade.core.boot.ctrl.BladeController;

/**
 * 联系人表 控制器
 *
 * @author BladeX
 * @since 2020-06-01
 */
@RestController
@AllArgsConstructor
@RequestMapping("contacts/contacts")
@Api(value = "联系人表", tags = "联系人表接口")
public class ContactsController extends BladeController {

	private IContactsService contactsService;
	private ILabelsService labelsService;


	/**
	 * 详情
	 */
	@GetMapping("/detail")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入contacts")
	public R<ContactsDTO> detail(ContactsVO contactsVo) {
		ContactsDTO detail = contactsService.getContactsDetail(contactsVo);
		return R.data(detail);
	}

	/**
	 * 分页 联系人表
	 */
	@GetMapping("/list")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "分页", notes = "传入contacts")
	public R<IPage<Contacts>> list(Contacts contacts, Query query) {
		IPage<Contacts> pages = contactsService.page(Condition.getPage(query), Condition.getQueryWrapper(contacts));
		return R.data(pages);
	}


	/**
	 * 分页 联系人表
	 */
	@GetMapping("/isBlackList")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "分页", notes = "传入contacts")
	public R<IPage<ContactsVO>> isBlackList(ContactsVO contacts, Query query) {
		IPage<ContactsVO> pages = contactsService.getBlackList(Condition.getPage(query), contacts);
		return R.data(pages);
	}


	/**
	 * 自定义分页 联系人表
	 */
	@GetMapping("/page")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页", notes = "传入contacts")
	public R<IPage<ContactsVO>> page(ContactsVO contacts, Query query) {
		IPage<ContactsVO> pages = contactsService.selectContactsPage(Condition.getPage(query), contacts);
		return R.data(pages);
	}

	/**
	 *
	 * @param
	 * @return
	 */
	@PostMapping("/listAll")
	@ApiOperationSupport(order = 8)
	@ApiOperation(value = "标签列表")
	public R list1() {
		return R.data(labelsService.list());
	}

	/**
	 *
	 * @param
	 * @return
	 */
	@GetMapping("/allList")
	@ApiOperationSupport(order = 8)
	@ApiOperation(value = "联系人列表")
	public R contactsList() {
		return R.data(contactsService.list());
	}
	/**
	 * 新增 联系人表
	 */
	@PostMapping("/save")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "新增", notes = "传入contacts")
	public R save(@Valid @RequestBody Contacts contacts)	 {
		return R.status(contactsService.save(contacts));
	}

	/**
	 * 修改 联系人表
	 */
	@PostMapping("/update")
	@ApiOperationSupport(order = 5)
	@ApiOperation(value = "修改", notes = "传入contacts")
	public R update(@Valid @RequestBody Contacts contacts) {
		return R.status(contactsService.updateById(contacts));
	}

	/**
	 * 新增或修改 联系人表
	 */
	@PostMapping("/submit")
	@ApiOperationSupport(order = 6)
	@ApiOperation(value = "新增或修改", notes = "传入contacts")
	public R submit(@Valid @RequestBody Contacts contacts) {
		return R.status(contactsService.saveOrUpdate(contacts));
	}


	/**
	 * 删除 联系人表
	 */
	@PostMapping("/remove")
	@ApiOperationSupport(order = 7)
	@ApiOperation(value = "逻辑删除", notes = "传入ids")
	public R remove(@ApiParam(value = "主键集合", required = true) @RequestParam String ids) {
		return R.status(contactsService.deleteLogic(Func.toLongList(ids)));
	}

	/**
	 * 添加到联系人黑名单表
	 */
	@PostMapping("/addBlackList")
	@ApiOperationSupport(order = 7)
	@ApiOperation(value = "添加到黑名单", notes = "传入id")
	public R addBlackList(@ApiParam(value = "主键集合", required = true) @RequestParam String id) {
		contactsService.addBlackList(id);
		return R.success("添加到黑名单成功");
	}
	/**
	 * 从联系人黑名单表删除
	 */
	@PostMapping("/removeBlackList")
	@ApiOperationSupport(order = 7)
	@ApiOperation(value = "从黑名单内删除", notes = "传入id")
	public R removeBlackList(@ApiParam(value = "主键集合", required = true) @RequestParam String id) {
		contactsService.removeBlackList(id);
		return R.success("移除黑名单成功");
	}
}
