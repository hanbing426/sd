package org.springblade.modules.note.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.core.mp.base.BaseService;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.note.entity.Note;

public interface IPhoneNoteService  extends BaseService<Note> {

	public R<IPage<Contacts>> noteContactsList(Note note , Contacts contacts, Query query);

	R saveNote( Note note,String ContactsId);

}
