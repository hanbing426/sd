package org.springblade.modules.enclosure.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springblade.core.boot.ctrl.BladeController;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.secure.annotation.PreAuth;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.constant.RoleConstant;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.enclosure.entity.Enclosure;
import org.springblade.modules.enclosure.service.IEnclosureService;
import org.springblade.modules.enclosure.service.IPhoneEnclosureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping("/phoneEnclosure/phoneEnclosure")
@Api(value = "后端附件表", tags = "后端附件表接口")
//@PreAuth(RoleConstant.HAS_ROLE_USER)
public class PhoneEnclosureController extends BladeController {

	@Autowired
	private IPhoneEnclosureService enclosureService;

	/**
	 * 查询附件列表
	 */
	@GetMapping("/enclosureList")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "查询附件列表", notes = "传入CantactsId")
	public R enclosureList(String CantactsId) {
		return enclosureService.enclosureList(CantactsId);
	}

}
