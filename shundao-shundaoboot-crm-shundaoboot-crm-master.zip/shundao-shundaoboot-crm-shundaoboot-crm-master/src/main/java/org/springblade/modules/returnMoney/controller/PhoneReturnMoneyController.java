package org.springblade.modules.returnMoney.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import oracle.jdbc.proxy.annotation.Post;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.api.R;
import org.springblade.modules.returnMoney.entity.ReturnMoney;
import org.springblade.modules.returnMoney.service.IPhoneReturnMoneyService;
import org.springblade.modules.returnMoney.vo.ReturnMoneyVO;
import org.springblade.modules.returnMoney.wrapper.ReturnMoneyWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.ws.rs.POST;
import java.util.HashMap;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/phoneReturnMoney")
@Api(value = "回款表", tags = "回款表接口")
public class PhoneReturnMoneyController {


	@Autowired
	private IPhoneReturnMoneyService phoneReturnMoneyService;
	@Autowired
	private  BladeRedis bladeRedis;
	/**
	 * 分页 回款表
	 */
	@GetMapping("/returnMoneyList")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "分页")
	public R list() {
		return R.data(phoneReturnMoneyService.returnMoneyList());
	}


	/**
	 *添加回款表
	 */
	@PostMapping("/saveReturnMoney")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "分页")
	public R saveReturnMoney(ReturnMoney returnMoney){
		return phoneReturnMoneyService.saveReturnMoney(returnMoney);
	}



//	/**
//	 *表单ID回调存储
//	 */
//	@PostMapping("/setFormDataId")
//	@ApiOperationSupport(order = 2)
//	@ApiOperation(value = "存储表单ID回调")
//	public R setFormDataId(String formDataId){
//		bladeRedis.setEx("formDataId",formDataId, (long) 72000);
//		return R.success(formDataId+">>操作成功");
//	}

	/**
	 *表单ID回调取值
	 */
	@PostMapping("/getFormDataId")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "获取表单ID回调")
	public R getFormDataId(){
		String formDataId = bladeRedis.get("formDataId");

		Map<String,String> returnData = new HashMap<>();
		returnData.put("formDataId",formDataId);
		bladeRedis.del("formDataId");
		return R.data(returnData,formDataId+">>操作成功");
	}

}
