package org.springblade.modules.contacts.vo;


import io.swagger.annotations.ApiModel;
import lombok.Data;
import org.springblade.modules.system.entity.User;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@ApiModel(value = "ContactsList对象", description = "联系人列表")
public class ContactsDetailVo {

	private Long id;

	private String sdAvatar;

	private String sdContactsName;

	private List<Map> sdLabelNameList;

	private String sdContactsPost;

	private Map sdContactsDept;

	private List<Map> sdGroupNameList;

	private String remarks;

	private List<User> sdContactsShareUser;

	private String sdContactsIphone;

	private String sdContactsEmail;

	private User sdContactsUser;

	private Integer ishighseas;

	private Integer sdContactsSex;//性别
}
