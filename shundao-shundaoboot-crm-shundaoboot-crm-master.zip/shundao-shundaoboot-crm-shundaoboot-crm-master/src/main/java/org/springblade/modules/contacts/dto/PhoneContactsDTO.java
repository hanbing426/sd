package org.springblade.modules.contacts.dto;

import org.springblade.modules.contacts.entity.Contacts;

import java.util.List;
import java.util.Map;

public class PhoneContactsDTO extends Contacts {

	private static final long serialVersionUID = 1L;

	private List<String> sdContactsLabelList;


}
