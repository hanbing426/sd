package org.springblade.modules.note.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.secure.BladeUser;
import org.springblade.core.secure.utils.SecureUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.api.ResultCode;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.service.IContactsService;
import org.springblade.modules.contacts.service.IPhoneContactsService;
import org.springblade.modules.contacts.service.impl.ContactsServiceImpl;
import org.springblade.modules.note.entity.Note;
import org.springblade.modules.note.mapper.NoteMapper;
import org.springblade.modules.note.service.IPhoneNoteService;
import org.springblade.modules.system.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IPhoneNoteServiceImpl extends BaseServiceImpl<NoteMapper, Note> implements IPhoneNoteService {

	@Autowired
	private IContactsService contactsService;

	@Autowired
	private IUserService userService;

	@Override
	public R saveNote(Note note, String ContactsId) {
		return R.status(this.saveOrUpdate(note));
	}

	@Override
	public R<IPage<Contacts>> noteContactsList(Note note, Contacts contacts, Query query) {
		contacts.setSdContactsIsHighSeas(0);
		return R.data(contactsService.page(Condition.getPage(query), Condition.getQueryWrapper(contacts)));
	}
}
