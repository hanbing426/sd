package org.springblade.modules.message.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.core.mp.base.BaseService;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.modules.message.entity.Message;

import java.util.List;
import java.util.Map;

public interface IPhoneMessageService extends BaseService<Message> {

	List<Message> messageList();

	Map newMessageCount();


	R ReadMessage(Message messageId);

	List<Message> approvalMessageList();
}
