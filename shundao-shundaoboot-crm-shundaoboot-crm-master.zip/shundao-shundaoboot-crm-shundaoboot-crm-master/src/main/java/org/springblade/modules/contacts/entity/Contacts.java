/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.contacts.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import org.springblade.core.mp.base.BaseEntity;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 联系人表实体类
 *
 * @author BladeX
 * @since 2020-06-01
 */
@Data
@TableName("sd_contacts")
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "Contacts对象", description = "联系人表")
public class Contacts extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/**
	 *联系人ID
	 */
	@ApiModelProperty(value = "联系人id")
	@TableId(value = "id",type = IdType.AUTO)
	private Long id;

	/**
	 * 联系人名称
	 */
	@ApiModelProperty(value = "联系人名称")
	private String sdContactsName;
	/**
	 * 联系人邮箱
	 */
	@ApiModelProperty(value = "联系人邮箱")
	private String sdContactsEmail;
	/**
	 * 联系人手机号
	 */
	@ApiModelProperty(value = "联系人手机号")
	private String sdContactsIphone;
	/**
	 * 联系人机构
	 */
	@ApiModelProperty(value = "联系人机构")
	private String sdContactsOrganization;



	/**
	 * 联系人群组
	 */
	@ApiModelProperty(value = "群组")
	private String sdContactsGroup;

	/**
	 * 联系人职位
	 */
	@ApiModelProperty(value = "联系人职位")
	private String sdContactsPost;
	/**
	 * 联系人标签
	 */
	@ApiModelProperty(value = "联系人标签")
	private String sdContactsLabel;
	/**
	 * 性别:1男0女
	 */
	@ApiModelProperty(value = "性别:1男0女")
	private Integer sdContactsSex;

	@ApiModelProperty(value = "头像")
	private String sdAvatar;

	/**
	 * 出生日期
	 */
	@ApiModelProperty(value = "出生日期")
	private LocalDateTime sdContactsBirthTime;

	/**
	 * 共享人多人逗号分开
	 */
	@ApiModelProperty(value = "共享人多人逗号分开")
	private String sdContactsShareUser;

	@ApiModelProperty(value = "联系人公海ID")
	private String sdContactsHighSeas;

	@ApiModelProperty(value = "是否归入公海:无0有1")
	private Integer sdContactsIsHighSeas;






}
