package org.springblade.modules.organization.Controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import oracle.jdbc.proxy.annotation.Pre;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.secure.annotation.PreAuth;
import org.springblade.core.secure.constant.AuthConstant;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.constant.RoleConstant;
import org.springblade.modules.organization.service.IOrganizationService;
import org.springblade.modules.system.entity.Dept;
import org.springblade.modules.system.entity.Role;
import org.springblade.modules.system.entity.Tenant;
import org.springblade.modules.system.service.IDeptService;
import org.springblade.modules.system.service.IRoleService;
import org.springblade.modules.system.service.ITenantService;
import org.springblade.modules.system.service.impl.DeptServiceImpl;
import org.springblade.modules.system.vo.DeptVO;
import org.springblade.modules.system.wrapper.DeptWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/phoneOrganization/phoneOrganization")
@Api(value = "后端机构表", tags = "机构表接口")
//@PreAuth(AuthConstant.DENY_ALL)
public class OrganizationController {

	@Autowired
	private IOrganizationService organizationService;


	/**
	 *
	 * @return
	 */
	@GetMapping("/organizationSelect")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入租户ID")
	public R organizationSelect(String userId ){
		return organizationService.organizationSelect(userId);
	}


	/**
	 * 筛选机构列表
	 * @return
	 */
	@GetMapping("/organizationSelectList")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "筛选机构列表")
	public R organizationSelectList(){
		return organizationService.organizationSelectList();
	}

	/**
	 *查询表情列表
	 */
	@GetMapping("/labelSelectList")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "筛选标签列表")
	public R labelSelectList(){
		return organizationService.labelSelectList();
	}

	/**
	 *筛选群组列表
	 */
	@GetMapping("/groupSelectList")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "筛选群组列表")
	public R groupSelectList(){
		return organizationService.groupSelectList();
	}

	/**
	 *筛选职位列表
	 */
	@GetMapping("/postSelectList")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "筛选职位列表")
	public R postSelectList(){
		return organizationService.postSelectList();
	}

	/**
	 *筛选共享人列表
	 */
	@GetMapping("/sharerSelectList")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "筛选共享人列表")
	public R SharerSelectList(){
		return organizationService.SharerSelectList();
	}

	/**
	 * 机构详情
	 */
	@GetMapping("/organizationSelectDetail")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "筛选机构列表")
	public R organizationSelectDetail(String deptId){
		return organizationService.organizationSelectDetail(deptId);
	}

	/**
	 *新建机构
	 */
	@PostMapping("/saveDept")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "新增机构")
	public R saveDept(Dept dept){
		return organizationService.saveDept(dept);
	}





}
