package org.springblade.modules.customerdata.dto;

import lombok.Data;
import org.springblade.core.mp.base.BaseEntity;
import org.springblade.modules.customerdata.entity.CustomerFormData;

import java.util.List;

/**
 * 自定义表单数据视图传输对象实体类
 *
 * @author BladeX
 * @since 2020-06-23
 */
@Data
public class CustomeFormDataView extends CustomerFormData {



}
