/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.message.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import org.springblade.core.mp.base.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 实体类
 *
 * @author BladeX
 * @since 2020-07-01
 */
@Data
@TableName("sd_message")
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "Message对象", description = "Message对象")
public class Message extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/**
	* 消息文本
	*/
		@ApiModelProperty(value = "消息文本")
		private String sdOperationText;

	@ApiModelProperty(value = "管理员Id")
	private String sdUserId;
	/**
	* 是否已阅
	*/
		@ApiModelProperty(value = "是否已阅")
		private Integer sdIsRead;

	@ApiModelProperty(value = "联系人Id")
	private String sdContactsId;

	private Integer sdMessageType;

	private String sdApprovalJson;

}
