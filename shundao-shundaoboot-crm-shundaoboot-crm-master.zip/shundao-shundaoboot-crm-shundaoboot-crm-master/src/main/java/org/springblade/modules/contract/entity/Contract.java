/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.contract.entity;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.TableName;
import org.springblade.core.mp.base.BaseEntity;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 合同表实体类
 *
 * @author BladeX
 * @since 2020-06-13
 */
@Data
@TableName("sd_contract")
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "Contract对象", description = "合同表")
public class Contract extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/**
	 * 合同名称
	 */
	@ApiModelProperty(value = "合同名称")
	private String sdContractName;
	/**
	 * 合同备注
	 */
	@ApiModelProperty(value = "合同备注")
	private String sdContractRemarks;
	/**
	 * 合同金额
	 */
	@ApiModelProperty(value = "合同金额")
	private BigDecimal sdContractMoney;
	/**
	 * 所属商机
	 */
	@ApiModelProperty(value = "所属商机")
	private Integer sdContractBusinessOpportunityId;
	/**
	 * 合同状态:1执行中2成功结束3意外终止
	 */
	@ApiModelProperty(value = "合同状态:1执行中2成功结束3意外终止")
	private String sdContractType;
	/**
	 * 合同开始日期
	 */
	@ApiModelProperty(value = "合同开始日期")
	private LocalDateTime sdContractStartTime;
	/**
	 * 合同结束日期
	 */
	@ApiModelProperty(value = "合同结束日期")
	private LocalDateTime sdContractEndTime;
	/**
	 * 合同编号
	 */
	@ApiModelProperty(value = "合同编号")
	private String sdContractCode;
	/**
	 * 合同签署日期
	 */
	@ApiModelProperty(value = "合同签署日期")
	private LocalDateTime sdContractSignTime;
	/**
	 * 客户签约人
	 */
	@ApiModelProperty(value = "客户签约人")
	private String sdContractYouSignedBy;
	/**
	 * 我方签约人
	 */
	@ApiModelProperty(value = "我方签约人")
	private String sdContractMySigendBy;
	/**
	 * 预计回款
	 */
	@ApiModelProperty(value = "预计回款")
	private BigDecimal sdContractExpectReturnMoney;
	/**
	 * 预计回款时间
	 */
	@ApiModelProperty(value = "预计回款时间")
	private LocalDateTime sdContractExpectReturnMoneyTime;
	/**
	 * 合同归属人
	 */
	@ApiModelProperty(value = "合同归属人")
	private String sdContractByUser;


}
