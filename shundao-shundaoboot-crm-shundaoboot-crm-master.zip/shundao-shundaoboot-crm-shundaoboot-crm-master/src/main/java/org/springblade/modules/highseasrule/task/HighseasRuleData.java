package org.springblade.modules.highseasrule.task;

import org.springblade.modules.highseasrule.entity.HighSeasRule;

public class HighseasRuleData extends HighSeasRule {

}
