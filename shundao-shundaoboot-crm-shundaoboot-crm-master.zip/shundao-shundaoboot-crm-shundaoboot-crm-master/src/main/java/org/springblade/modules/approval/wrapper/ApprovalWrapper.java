/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.approval.wrapper;

import org.springblade.core.mp.support.BaseEntityWrapper;
import org.springblade.core.tool.utils.BeanUtil;
import org.springblade.modules.approval.entity.Approval;
import org.springblade.modules.approval.vo.ApprovalVO;
import java.util.Objects;

/**
 * 审批流程包装类,返回视图层所需的字段
 *
 * @author BladeX
 * @since 2020-07-25
 */
public class ApprovalWrapper extends BaseEntityWrapper<Approval, ApprovalVO>  {

	public static ApprovalWrapper build() {
		return new ApprovalWrapper();
 	}

	@Override
	public ApprovalVO entityVO(Approval approval) {
		ApprovalVO approvalVO = Objects.requireNonNull(BeanUtil.copy(approval, ApprovalVO.class));

		//User createUser = UserCache.getUser(approval.getCreateUser());
		//User updateUser = UserCache.getUser(approval.getUpdateUser());
		//approvalVO.setCreateUserName(createUser.getName());
		//approvalVO.setUpdateUserName(updateUser.getName());

		return approvalVO;
	}

}
