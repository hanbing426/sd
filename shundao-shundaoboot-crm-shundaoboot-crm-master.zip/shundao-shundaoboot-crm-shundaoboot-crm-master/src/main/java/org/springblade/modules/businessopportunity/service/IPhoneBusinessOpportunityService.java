package org.springblade.modules.businessopportunity.service;

import org.springblade.core.mp.base.BaseService;
import org.springblade.core.tool.api.R;
import org.springblade.modules.businessopportunity.dto.BusinessOpportunityDetailDTO;
import org.springblade.modules.businessopportunity.entity.BusinessOpportunity;

import java.util.List;
import java.util.Map;

public interface IPhoneBusinessOpportunityService extends BaseService<BusinessOpportunity> {



	List<BusinessOpportunity> businessOpportunityRuleSelect( String contactsId);

	Map BusinessOpportunityRule();

	BusinessOpportunityDetailDTO BusinessOpportunityDetail(String id);

	Map fillInBusinessOpportunity();

	R saveBusinessOpportunity(BusinessOpportunity businessOpportunity);


}
