/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.contacts.service;

import org.springblade.core.tool.api.R;
import org.springblade.modules.contacts.dto.ContactsDTO;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.vo.ContactsVO;
import org.springblade.core.mp.base.BaseService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.modules.enclosure.entity.Enclosure;

import java.util.List;

/**
 * 联系人表 服务类
 *
 * @author BladeX
 * @since 2020-06-01
 */
public interface IContactsService extends BaseService<Contacts> {

	/**
	 * 自定义分页
	 *
	 * @param page
	 * @param contacts
	 * @return
	 */
	IPage<ContactsVO> selectContactsPage(IPage<ContactsVO> page, ContactsVO contacts);

	/**
	 * 返回单条联系人的所有信息
	 * @param contacts
	 * @return
	 */
	ContactsDTO getContactsDetail(ContactsVO contacts);

	/**
	 * 查询类名单列表自定义分页
	 * @param page
	 * @param contacts
	 * @return
	 */
	IPage<ContactsVO> getBlackList(IPage<ContactsVO> page, ContactsVO contacts);

	void addBlackList(String id);

	void removeBlackList(String id);
}
