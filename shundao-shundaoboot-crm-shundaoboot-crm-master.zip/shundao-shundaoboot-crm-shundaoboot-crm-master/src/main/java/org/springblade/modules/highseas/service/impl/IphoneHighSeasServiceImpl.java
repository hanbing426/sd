package org.springblade.modules.highseas.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.modules.contacts.entity.Contacts;
import org.springblade.modules.contacts.service.IContactsService;
import org.springblade.modules.highseas.entity.HighSeas;
import org.springblade.modules.highseas.mapper.HighSeasMapper;
import org.springblade.modules.highseas.service.IHighSeasService;
import org.springblade.modules.highseas.service.IphoneHighSeasService;
import org.springblade.modules.system.service.IDeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IphoneHighSeasServiceImpl extends BaseServiceImpl<HighSeasMapper, HighSeas> implements IphoneHighSeasService {


	@Autowired
	private IHighSeasService highSeasService;


	@Autowired
	private IDeptService deptService;


	@Override
	public List<HighSeas> highSeaslist() {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.select("id,sd_high_seas_name");
		List<HighSeas> list = highSeasService.listMaps(queryWrapper);;
		return list;
	}

	@Override
	public R deptList() {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("dept_category",1);
		queryWrapper.select("id,dept_name");
		return R.data(deptService.listMaps(queryWrapper));
	}
}
