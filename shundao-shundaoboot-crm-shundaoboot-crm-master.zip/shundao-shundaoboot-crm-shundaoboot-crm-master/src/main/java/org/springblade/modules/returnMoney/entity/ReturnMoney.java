/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.returnMoney.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import org.springblade.core.mp.base.BaseEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 回款表实体类
 *
 * @author BladeX
 * @since 2020-07-25
 */
@Data
@TableName("sd_return_money")
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "ReturnMoney对象", description = "回款表")
public class ReturnMoney extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/**
	* 本次回款金额
	*/
		@ApiModelProperty(value = "本次回款金额")
		private BigDecimal sdReturnMoney;
	/**
	* 回款时间
	*/
		@org.springframework.format.annotation.DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
		@com.fasterxml.jackson.annotation.JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
		@ApiModelProperty(value = "回款时间")
		private LocalDateTime sdReturnMoneyTime;
	/**
	* 付款方式
	*/
		@ApiModelProperty(value = "付款方式")
		private String sdReturnMoneyType;
	/**
	* 回款备注
	*/
		@ApiModelProperty(value = "回款备注")
		private String sdReturnMoneyRemarks;
	/**
	* 回款所属联系人
	*/
		@ApiModelProperty(value = "回款所属联系人")
		private String sdReturnMoneyContactsId;
	/**
	* 回款所属公司
	*/
		@ApiModelProperty(value = "回款所属公司")
		private String sdReturnMoneyDeptId;
	/**
	* 自定义表单数据ID
	*/
		@ApiModelProperty(value = "自定义表单数据ID")
		private String sdReturnMoneyCustomId;

	@ApiModelProperty(value = "按钮ID")
	private String sdReturnMoneyMenuId;

	@ApiModelProperty(value = "当前审核组Id")
	private String sdReturnMoneyApprovalConduct;

	@ApiModelProperty(value = "审核节点索引")
	private Integer sdReturnMoneyApprovalIndex;

}
