package org.springblade.modules.customapprovalmenu.dto;

import lombok.Data;
import org.flowable.spring.boot.app.App;
import org.springblade.modules.approval.dto.ApprovalUserListDTO;

import java.util.List;
import java.util.Map;

@Data
public class CustomApprovalMenuList {

	private
	Long id ;

	private
	String groupId;

	private List<ApprovalUserListDTO> approvalUserListDTOS;


}
