package org.springblade.modules.businessopportunity.controller;

import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springblade.core.tool.api.R;
import org.springblade.modules.businessopportunity.entity.BusinessOpportunity;
import org.springblade.modules.businessopportunity.service.IPhoneBusinessOpportunityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping("/phoneBusinessopportunity/phoneBusinessopportunity")
@Api(value = "", tags = "接口")
//@PreAuth(RoleConstant.HAS_ROLE_USER)
public class PhoneBusinessOpportunityController {

	@Autowired
	private IPhoneBusinessOpportunityService businessOpportunityService;

	/**
	 *商机筛选条件
	 */
	@GetMapping("/BusinessOpportunityRule")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "商机查询所需条件")
	public R BusinessOpportunityRule(){
		return R.data(businessOpportunityService.BusinessOpportunityRule());
	}

	/**
	 * 商机条件查询  所属机构 联系人
	 */
	@PostMapping("/BusinessOpportunityRuleSelect")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "商机条件查询列表", notes = "或者联系人ID，空值就是全部查询")
	public R BusinessOpportunityRuleSelect( String contactsId){
			return R.data(businessOpportunityService.businessOpportunityRuleSelect(contactsId));
	}

	/**
	 * 商机详情
	 */
	@GetMapping("/BusinessOpportunityDetail")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "商机详情", notes = "传入商机id")
	public R BusinessOpportunityDetail(String id){
		return R.data(businessOpportunityService.BusinessOpportunityDetail(id));
	}

	/**
	 * 填写商机
	 */
	@GetMapping("/fillInBusinessOpportunity")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "填写商机")
	public R fillInBusinessOpportunity(){
		return R.data(businessOpportunityService.fillInBusinessOpportunity());
	}

	/**
	 * 插入商机
	 */
	@PostMapping("/saveBusinessOpportunity")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "插入商机")
	public R saveBusinessOpportunity(BusinessOpportunity businessOpportunity){
		return R.data(businessOpportunityService.saveBusinessOpportunity( businessOpportunity));
	}
}
