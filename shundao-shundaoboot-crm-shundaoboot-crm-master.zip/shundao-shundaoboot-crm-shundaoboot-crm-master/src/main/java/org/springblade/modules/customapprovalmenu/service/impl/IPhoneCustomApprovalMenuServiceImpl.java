package org.springblade.modules.customapprovalmenu.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sun.org.apache.xml.internal.security.utils.JavaUtils;
import org.aspectj.bridge.IMessage;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.secure.utils.SecureUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.jackson.JsonUtil;
import org.springblade.core.tool.utils.StringUtil;
import org.springblade.modules.approval.entity.Approval;
import org.springblade.modules.approval.service.IApprovalService;
import org.springblade.modules.approval.service.impl.ApprovalServiceImpl;
import org.springblade.modules.customapprovalmenu.dto.CustomApprovalMenuList;
import org.springblade.modules.customapprovalmenu.dto.CustomApprovalReturnList;
import org.springblade.modules.customapprovalmenu.entity.CustomApprovalMenu;
import org.springblade.modules.customapprovalmenu.mapper.CustomApprovalMenuMapper;
import org.springblade.modules.customapprovalmenu.service.ICustomApprovalMenuService;
import org.springblade.modules.customapprovalmenu.service.IPhoneCustomApprovalMenuService;
import org.springblade.modules.message.entity.Message;
import org.springblade.modules.message.service.IMessageService;
import org.springblade.modules.returnMoney.entity.ReturnMoney;
import org.springblade.modules.returnMoney.service.IReturnMoneyService;
import org.springblade.modules.sdapprovalgroup.entity.ApprovalGroup;
import org.springblade.modules.sdapprovalgroup.service.IApprovalGroupService;
import org.springblade.modules.system.service.IDictBizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.management.Query;
import java.util.List;

@Service
public class IPhoneCustomApprovalMenuServiceImpl extends BaseServiceImpl<CustomApprovalMenuMapper, CustomApprovalMenu> implements IPhoneCustomApprovalMenuService {


	@Autowired
	private IApprovalService approvalService;

	@Autowired
	private CustomApprovalMenuMapper customApprovalMenuMapper;

	@Autowired
	private IReturnMoneyService returnMoneyService;

	@Autowired
	private IApprovalGroupService approvalGroupService;

	@Autowired
	private IMessageService messageService;

	@Autowired
	private IDictBizService dictBizService;

	@Override
	public CustomApprovalMenuList saveList(String menuId) {
		CustomApprovalMenuList customApprovalMenuList = customApprovalMenuMapper.saveList(menuId);
		return customApprovalMenuList;
	}

	@Override
	public R approvalList(String status) {
		Long userId = SecureUtil.getUserId();
		if(StringUtil.isBlank(status)){
			status = "1";
		}
			List<CustomApprovalReturnList> returnMonies = customApprovalMenuMapper.approvalList(String.valueOf(userId), status);
			return R.data(returnMonies);
	}

	/**
	 * 要returnMoneyId
	 * @param returnMoney
	 * @param status
	 * @return
	 */
	@Override
	public R updateApprovalStatus(ReturnMoney returnMoney , Integer status) {
		String rmId = String.valueOf(returnMoney.getId());
		if(StringUtil.isNotBlank(rmId)) {
			QueryWrapper rmQureyWrapper = new QueryWrapper();
			rmQureyWrapper.eq("id", rmId);
			ReturnMoney returnMoneyOne = returnMoneyService.getOne(rmQureyWrapper);
			if (returnMoneyOne == null) {
				return R.data("31", "查询回款ID对象为空");
			} else {
			String sdReturnMoneyApprovalConduct = returnMoneyOne.getSdReturnMoneyApprovalConduct();
			QueryWrapper queryWrapper = new QueryWrapper();
			queryWrapper.eq("id", sdReturnMoneyApprovalConduct);
			List<Approval> list = approvalService.list(queryWrapper);
				if (list.size() > 0) {
				Approval approval = list.get(0);
				//查询索引最大值
					String sdApprovalGroupId = approval.getSdApprovalGroupId();
					QueryWrapper queryWrapperThree = new QueryWrapper();
					queryWrapperThree.eq("sd_approval_group_id",sdApprovalGroupId);
					int count = approvalService.count(queryWrapperThree);
					switch (status) {
					case 2: {
						if (approval.getSdApprovalIndex() <= count-1) {
							QueryWrapper queryWrapper2 = new QueryWrapper();
							queryWrapper2.eq("sd_approval_group_id", approval.getSdApprovalGroupId());
							queryWrapper2.eq("sd_approval_index", approval.getSdApprovalIndex() + 1);
							Approval one = approvalService.getOne(queryWrapper2);
							returnMoneyOne.setSdReturnMoneyApprovalConduct(String.valueOf(one.getId()));
							returnMoneyOne.setSdReturnMoneyApprovalIndex(approval.getSdApprovalIndex()+1);
							returnMoneyOne.setStatus(1);
							boolean b = returnMoneyService.saveOrUpdate(returnMoneyOne);
							boolean b1 = approvalService.saveOrUpdate(approval);
							approval.setStatus(2);
							Message message = new Message();
							message.setSdMessageType(1);
							message.setSdApprovalJson(JsonUtil.toJson(approval));
							message.setSdIsRead(0);
							message.setSdUserId(String.valueOf(SecureUtil.getUserId()));
							boolean b2 = messageService.saveOrUpdate(message);
							if (b1 && b && b2) {
								return R.status(true);
							} else {
								return R.status(false);
							}
						} else {
							QueryWrapper queryWrapper1 = new QueryWrapper();
							queryWrapper1.eq("id", String.valueOf(rmId));
							List<ReturnMoney> list1 = returnMoneyService.list(queryWrapper1);
							if (list1.size() > 0) {
								Message message = new Message();
								message.setSdMessageType(1);
								message.setSdApprovalJson(JsonUtil.toJson(approval));
								message.setSdIsRead(0);
								message.setSdUserId(String.valueOf(SecureUtil.getUserId()));
								messageService.saveOrUpdate(message);
								ReturnMoney returnMoneyTow = list1.get(0);
								returnMoneyTow.setStatus(2);
								return R.status(returnMoneyService.saveOrUpdate(returnMoneyTow));
							} else {
								return R.fail(37,"根据回款ID未查询到响应回款数据");
							}
						}
					}
					case 3: {
						approval.setStatus(status);
						QueryWrapper queryWrapper1 = new QueryWrapper();
						queryWrapper1.eq("id", rmId);
						List<ReturnMoney> list1 = returnMoneyService.list(queryWrapper1);
						if (list1.size() > 0) {
							ReturnMoney returnMoney1 = list1.get(0);
							returnMoney1.setStatus(3);
							returnMoney1.setSdReturnMoneyApprovalConduct(String.valueOf(approval.getId()));
							returnMoneyService.saveOrUpdate(returnMoney1);
						}else {
							return R.fail(35,"回款表审核数据不足，子节点id错误");
						}
						Message message = new Message();
						message.setSdMessageType(1);
						message.setSdApprovalJson(JsonUtil.toJson(approval));
						message.setSdIsRead(0);
						message.setSdUserId(String.valueOf(SecureUtil.getUserId()));
						boolean b1 = messageService.saveOrUpdate(message);
						if (b1) {
							return R.status(true);
						} else {
							return R.status(false);
						}
					}
				}
			} else {
				return R.fail(32, "回款表数据有误，无法根据审核id查询审核节点");
			}
		}
		}else {
			return R.fail(30,"回款id为空");
		}
		return null;
	}

	@Override
	public R approvalDetail(String id) {
		Long s = SecureUtil.getUserId();
		String userId = String.valueOf(s);
		return R.data(customApprovalMenuMapper.approvalDetail(userId,id));
	}
}
