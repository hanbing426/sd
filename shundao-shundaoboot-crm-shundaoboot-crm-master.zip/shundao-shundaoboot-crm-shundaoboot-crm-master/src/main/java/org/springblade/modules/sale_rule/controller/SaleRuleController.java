/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.sale_rule.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import lombok.AllArgsConstructor;
import javax.validation.Valid;

import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestParam;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.modules.sale_rule.entity.SaleRule;
import org.springblade.modules.sale_rule.vo.SaleRuleVO;
import org.springblade.modules.sale_rule.service.ISaleRuleService;
import org.springblade.core.boot.ctrl.BladeController;

/**
 * 销售提醒规则表 控制器
 *
 * @author BladeX
 * @since 2020-05-29
 */
@RestController
@AllArgsConstructor
@RequestMapping("sale_rule/salerule")
@Api(value = "销售提醒规则表", tags = "销售提醒规则表接口")
public class SaleRuleController extends BladeController {

	private ISaleRuleService saleRuleService;

	/**
	 * 详情
	 */
	@GetMapping("/detail")
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "详情", notes = "传入saleRule")
	public R<SaleRule> detail(SaleRule saleRule) {
		SaleRule detail = saleRuleService.getOne(Condition.getQueryWrapper(saleRule));
		return R.data(detail);
	}

	/**
	 * 分页 销售提醒规则表
	 */
	@GetMapping("/list")
	@ApiOperationSupport(order = 2)
	@ApiOperation(value = "分页", notes = "传入saleRule")
	public R<IPage<SaleRule>> list(SaleRule saleRule, Query query) {
		IPage<SaleRule> pages = saleRuleService.page(Condition.getPage(query), Condition.getQueryWrapper(saleRule));
		return R.data(pages);
	}

	/**
	 * 自定义分页 销售提醒规则表
	 */
	@GetMapping("/page")
	@ApiOperationSupport(order = 3)
	@ApiOperation(value = "分页", notes = "传入saleRule")
	public R<IPage<SaleRuleVO>> page(SaleRuleVO saleRule, Query query) {
		IPage<SaleRuleVO> pages = saleRuleService.selectSaleRulePage(Condition.getPage(query), saleRule);
		return R.data(pages);
	}

	/**
	 * 新增 销售提醒规则表
	 */
	@PostMapping("/save")
	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "新增", notes = "传入saleRule")
	public R save(@Valid @RequestBody SaleRule saleRule) {
		return R.status(saleRuleService.save(saleRule));
	}

	/**
	 * 修改 销售提醒规则表
	 */
	@PostMapping("/update")
	@ApiOperationSupport(order = 5)
	@ApiOperation(value = "修改", notes = "传入saleRule")
	public R update(@Valid @RequestBody SaleRule saleRule) {
		return R.status(saleRuleService.updateById(saleRule));
	}

	/**
	 * 新增或修改 销售提醒规则表
	 */
	@PostMapping("/submit")
	@ApiOperationSupport(order = 6)
	@ApiOperation(value = "新增或修改", notes = "传入saleRule")
	public R submit(@Valid @RequestBody SaleRule saleRule) {
		return R.status(saleRuleService.saveOrUpdate(saleRule));
	}


	/**
	 * 删除 销售提醒规则表
	 */
	@PostMapping("/remove")
	@ApiOperationSupport(order = 7)
	@ApiOperation(value = "逻辑删除", notes = "传入ids")
	public R remove(@ApiParam(value = "主键集合", required = true) @RequestParam String ids) {
		return R.status(saleRuleService.deleteLogic(Func.toLongList(ids)));
	}




}
