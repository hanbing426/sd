/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.modules.highseas.dto;

import io.swagger.annotations.ApiModelProperty;
import org.springblade.modules.highseas.entity.HighSeas;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.sql.Time;
import java.time.LocalDateTime;

/**
 * 公海表数据传输对象实体类
 *
 * @author BladeX
 * @since 2020-05-27
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class HighSeasDTO extends HighSeas {
	private static final long serialVersionUID = 1L;



	/**
	 * 公海ID
	 */
	private String sdHighSeasId;
	/**
	 * 第一标签ID(以逗号分隔多个)
	 */
	private String sdLabelsIdOne;
	/**
	 * 第二标签ID(以逗号分隔多个)
	 */
	private String sdLabelsIdTwo;
	/**
	 * 第三标签ID(以逗号分隔多个)
	 */
	private String sdLabelsIdThree;
	/**
	 * 普通未跟进/未成交 天数
	 */
	private Integer sdHighSeasDays;
	/**
	 * 第一未跟进/未成交 天数
	 */
	private Integer sdHighSeasDaysOne;
	/**
	 * 第二未跟进/未成交 天数
	 */
	private Integer sdHighSeasDaysTwo;
	/**
	 * 提前提醒天数
	 */
	private Integer sdHighSeasRemindDays;
	/**
	 * 提醒时间
	 */
	private Time sdHighSeasRemindTime;
	/**
	 * 划入公海时间
	 */
	private Time sdHighSeasTime;
	/**业务字典获取
	 * 1超过XX天未跟进的客户划入公海
	 2根据客户类型及未跟进天数分别设置划入公海
	 3超过多少天未成交的客户划入公海
	 4根据客户类型及未成交天分别设置数划入公海
	 5不划入
	 */
	private Integer sdHighSeasType;
	/**
	 * 禁止同一人抢回天数
	 */
	private Integer sdHighSeasBanGet;
	/**
	 * 禁止抢回开关
	 */
	private Integer sdHighSeasBanOn;
	/**
	 * 第三未跟进/未成交 天数
	 */
	private Integer sdHighSeasDaysThree;
}
